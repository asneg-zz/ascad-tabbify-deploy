"""``vcad-run`` — run a vcad-py script and push the built scene to a running
ASCAD tab over the "external run" pairing channel.

You write a normal vcad-py script in your own editor (e.g. Cursor), keep a
top-level ``Scene`` (a variable named ``scene`` by convention), and run::

    vcad-run part.py --url http://localhost:7910 --key ABCD-EFGH --watch

The script is executed in a throwaway namespace, the resulting scene is
serialized with ``Scene.to_dict()`` and POSTed to ``<url>/scene-push?key=<key>``.
The browser tab that turned on "Внешний запуск" with the same key rebuilds the
model. With ``--watch`` the script re-runs on every save.

Uses only the standard library so it stays installable anywhere vcad-py is.
"""

from __future__ import annotations

import argparse
import json
import runpy
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from .builders import Scene


def _find_scene(namespace: dict[str, Any]) -> Scene | None:
    """Pick the Scene a script produced. Prefer a variable literally named
    ``scene``; otherwise take the last Scene instance bound in the module
    namespace (so ``s = Scene(); ...`` still works)."""
    candidate = namespace.get("scene")
    if isinstance(candidate, Scene):
        return candidate
    found: Scene | None = None
    for value in namespace.values():
        if isinstance(value, Scene):
            found = value
    return found


def _push(url: str, key: str, scene: Scene) -> tuple[bool, str]:
    """POST the scene to <url>/scene-push?key=<key>. Returns (ok, message)."""
    endpoint = f"{url.rstrip('/')}/scene-push?key={urllib.parse.quote(key)}"
    body = json.dumps(scene.to_dict()).encode("utf-8")
    req = urllib.request.Request(
        endpoint,
        data=body,
        method="POST",
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            text = resp.read().decode("utf-8", errors="replace")
        try:
            delivered = json.loads(text).get("delivered", 0)
        except (json.JSONDecodeError, AttributeError):
            delivered = "?"
        if delivered == 0:
            return True, "pushed, but no listening tab (open ASCAD and enable «Внешний запуск» with this key)"
        return True, f"pushed → {delivered} tab(s)"
    except urllib.error.HTTPError as e:
        return False, f"HTTP {e.code} {e.reason}"
    except urllib.error.URLError as e:
        return False, f"cannot reach {endpoint}: {e.reason}"


def _run_once(path: Path, url: str, key: str) -> None:
    """Execute the script and push its scene. Exceptions from the user's
    script are caught and printed so --watch keeps running."""
    try:
        ns = runpy.run_path(str(path), run_name="__vcad_run__")
    except Exception as e:  # noqa: BLE001 — surface any script error, keep watching
        print(f"  ✗ script error: {type(e).__name__}: {e}", file=sys.stderr)
        return
    scene = _find_scene(ns)
    if scene is None:
        print("  ✗ no Scene found — keep a top-level `scene = Scene()` in the script", file=sys.stderr)
        return
    ok, msg = _push(url, key, scene)
    print(f"  {'✓' if ok else '✗'} {msg}", file=sys.stderr if not ok else sys.stdout)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="vcad-run",
        description="Run a vcad-py script and build the model in a running ASCAD tab.",
    )
    parser.add_argument("file", help="path to the vcad-py script")
    parser.add_argument("--url", required=True, help="ai-proxy base URL, e.g. http://localhost:7910 or https://ascad3d.ru/api")
    parser.add_argument("--key", required=True, help="pairing key shown in ASCAD → «Внешний запуск»")
    parser.add_argument("--watch", action="store_true", help="re-run on every file save")
    args = parser.parse_args(argv)

    path = Path(args.file)
    if not path.exists():
        print(f"error: {path} does not exist", file=sys.stderr)
        return 2

    print(f"vcad-run: {path.name} → {args.url} (key {args.key})", file=sys.stderr)
    _run_once(path, args.url, args.key)

    if not args.watch:
        return 0

    print("  watching for changes — Ctrl+C to stop", file=sys.stderr)
    last = path.stat().st_mtime
    try:
        while True:
            time.sleep(0.4)
            try:
                mtime = path.stat().st_mtime
            except OSError:
                continue  # file briefly gone during an editor's atomic save
            if mtime != last:
                last = mtime
                print(f"— {time.strftime('%H:%M:%S')} change detected", file=sys.stderr)
                _run_once(path, args.url, args.key)
    except KeyboardInterrupt:
        print("\nstopped", file=sys.stderr)
        return 0


if __name__ == "__main__":
    sys.exit(main())
