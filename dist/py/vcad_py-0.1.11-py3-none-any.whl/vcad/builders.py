"""Fluent builder API on top of the Pydantic models.

The builders hold the underlying `SceneDoc`/`BodyDoc`/`SketchDoc` and offer
ergonomic methods that return element ids so the caller can reference them
later (construction, future constraints, …).
"""

from __future__ import annotations

import base64
import json
import math
import sys
from pathlib import Path
from typing import Literal, Sequence, TypeAlias, Union

from vcad.models import (
    AngleConstraint,
    ArcElement,
    AssemblyDoc,
    BodyDoc,
    Chamfer3DParams,
    CircleElement,
    CircularPattern3DParams,
    CoincidentConstraint,
    CoincidentMate,
    ConcentricConstraint,
    ConcentricMate,
    DimensionElement,
    DistanceConstraint,
    DistanceMate,
    EdgeCoincidentMate,
    EdgeRefDoc,
    EdgeVertices,
    EllipseElement,
    EqualConstraint,
    FaceAnchor,
    FaceCoordSystem,
    FaceGeomDoc,
    FaceRefDoc,
    Feature,
    Fillet3DParams,
    FixedConstraint,
    FixMate,
    HorizontalConstraint,
    LinearPattern3DParams,
    LineElement,
    LoftParams,
    Mate,
    MidpointConstraint,
    MirrorParams,
    NamedEntity,
    NamedEntityAnchor,
    ParallelConstraint,
    PartInstanceDoc,
    PartRef,
    PerpendicularConstraint,
    Plane,
    Point2D,
    PointElement,
    PointCoincidentMate,
    PointOnCircleConstraint,
    PointOnEdgeMate,
    PointOnLineConstraint,
    PointRef,
    PolygonElement,
    PolylineElement,
    Primitive,
    RadiusConstraint,
    PrismaticMate,
    RectangleElement,
    RevoluteMate,
    RotationalDrive,
    TranslationalDrive,
    ScaleBodyParams,
    SceneDoc,
    ShellParams,
    SketchConstraint,
    StepImportParams,
    SketchDoc,
    SketchElement,
    SlotElement,
    SplineElement,
    SymmetricConstraint,
    TangentConstraint,
    TangentMate,
    TextElement,
    Transform,
    Transform3D,
    VertexRefDoc,
    VerticalConstraint,
)
from vcad.text import text_to_contours

# Point tuple shorthand accepted everywhere a Point2D is expected.
PointLike = Point2D | tuple[float, float]

# A reference to a specific vertex of an element. Accepts either:
#   - just the element id (uses point_index=0; sensible for circle.center,
#     polygon.center etc.)
#   - (id, "start" | "end" | "center" | int) — name resolved per element type
PointSpec = str | tuple[str, "str | int"]


def _pt(p: PointLike) -> Point2D:
    if isinstance(p, Point2D):
        return p
    x, y = p
    return Point2D(x=float(x), y=float(y))


def _find_var_name(value: float) -> str | None:
    """Best-effort: the caller's variable whose value equals ``value`` — so a
    dimension can show "(W)" / "(c5)" for the script parameter that drives it.
    Returns None when there's no match or it's ambiguous (more than one). Called
    from a Sketch method, so the user's frame is two up. Never raises."""
    try:
        frame = sys._getframe(2)  # 0=here, 1=Sketch.dimension, 2=user script
        scope = {**frame.f_globals, **frame.f_locals}
        hits = [
            k for k, v in scope.items()
            if not k.startswith("_")
            and isinstance(v, (int, float)) and not isinstance(v, bool)
            and abs(float(v) - float(value)) < 1e-9
        ]
        return hits[0] if len(hits) == 1 else None
    except Exception:
        return None


def _sine_expr(amplitude: float, freq_hz: float, phase_deg: float) -> str:
    """A·sin(2π·freq·t [+ phase]) as a SymbolicParser f(`time`). `amplitude` is
    in the drive's own units (radians for angle, mm for distance). Spaces around
    operators — the SymbolicParser is space-sensitive."""
    w = 2.0 * math.pi * freq_hz
    inner = f"{w:.6g} * time"
    if phase_deg:
        inner += f" + {math.radians(phase_deg):.6g}"
    return f"{amplitude:.6g} * sin({inner})"


# Point-name semantics per element type. Matches the convention used by
# Sketch picking handlers in wasm_vCAD/src/components/viewport/sketch3D/.
_POINT_NAME_INDEX: dict[str, dict[str, int]] = {
    "line":     {"start": 0, "end": 1},
    "arc":      {"center": 0, "start": 1, "end": 2},
    "circle":   {"center": 0},
    "ellipse":  {"center": 0},
    "polygon":  {"center": 0},
    "slot":     {"start": 0, "end": 1},
    "rectangle": {"corner": 0},
    "point":    {"position": 0},
}


# ─── Sketch builder ─────────────────────────────────────────────────────────


class Sketch:
    """Fluent wrapper around a SketchDoc. Each `add_*` method appends an
    element and returns its id; the SketchDoc is mutated in place.

    `feature_id` is the id of the enclosing Feature{type:'sketch'} — it's
    what extrude/cut/revolve reference via their `sketch_id` field.
    """

    def __init__(self, doc: SketchDoc, feature_id: str) -> None:
        self._doc = doc
        self._feature_id = feature_id

    @property
    def id(self) -> str:
        """ID of the enclosing sketch Feature (referenced by extrude/cut)."""
        return self._feature_id

    # ─── Element factories ────────────────────────────────────────────────

    def point(self, position: PointLike) -> str:
        el = PointElement(position=_pt(position))
        self._doc.elements.append(el)
        return el.id

    def line(self, start: PointLike, end: PointLike) -> str:
        el = LineElement(start=_pt(start), end=_pt(end))
        self._doc.elements.append(el)
        return el.id

    def circle(self, center: PointLike, radius: float) -> str:
        el = CircleElement(center=_pt(center), radius=float(radius))
        self._doc.elements.append(el)
        return el.id

    def arc(
        self,
        center: PointLike,
        radius: float,
        start_angle: float,
        end_angle: float,
    ) -> str:
        el = ArcElement(
            center=_pt(center),
            radius=float(radius),
            start_angle=float(start_angle),
            end_angle=float(end_angle),
        )
        self._doc.elements.append(el)
        return el.id

    def rectangle(
        self,
        corner: PointLike,
        width: float,
        height: float,
    ) -> str:
        el = RectangleElement(
            corner=_pt(corner),
            width=float(width),
            height=float(height),
        )
        self._doc.elements.append(el)
        return el.id

    def rectangle_centered(self, center: PointLike, width: float, height: float) -> str:
        """Convenience: rectangle described by centre + size."""
        c = _pt(center)
        return self.rectangle(
            corner=(c.x - width / 2, c.y - height / 2),
            width=width,
            height=height,
        )

    def polyline(self, points: Sequence[PointLike]) -> str:
        el = PolylineElement(points=[_pt(p) for p in points])
        self._doc.elements.append(el)
        return el.id

    def spline(self, points: Sequence[PointLike]) -> str:
        el = SplineElement(points=[_pt(p) for p in points])
        self._doc.elements.append(el)
        return el.id

    def polygon(self, center: PointLike, radius: float, sides: int) -> str:
        el = PolygonElement(
            center=_pt(center),
            radius=float(radius),
            sides=int(sides),
        )
        self._doc.elements.append(el)
        return el.id

    def ellipse(
        self,
        center: PointLike,
        radius_x: float,
        radius_y: float,
        rotation: float = 0.0,
    ) -> str:
        el = EllipseElement(
            center=_pt(center),
            radiusX=float(radius_x),
            radiusY=float(radius_y),
            rotation=float(rotation),
        )
        self._doc.elements.append(el)
        return el.id

    def slot(self, start: PointLike, end: PointLike, radius: float) -> str:
        el = SlotElement(start=_pt(start), end=_pt(end), radius=float(radius))
        self._doc.elements.append(el)
        return el.id

    def text(self, position: PointLike, text: str, height: float = 10.0) -> str:
        """Editable text element. ``position`` is the baseline-left anchor,
        ``height`` the em size in sketch units. Glyph outlines (DejaVu Sans,
        Cyrillic + Latin) are baked into the element so the viewer/extruder
        need no font. Letter counters (О/Р/В…) become holes when extruded;
        a cut keeps them as material islands (engraved text)."""
        contours = text_to_contours(text, float(height))
        el = TextElement(
            position=_pt(position),
            text=text,
            font_size=float(height),
            text_contours=[[Point2D(x=x, y=y) for (x, y) in loop] for loop in contours],
        )
        self._doc.elements.append(el)
        return el.id

    def dimension(
        self,
        element: str | None = None,
        kind: str | None = None,
        *,
        from_: PointLike | None = None,
        to: PointLike | None = None,
        value: float | None = None,
        dimension_type: str = "linear",
        name: str | None = None,
    ) -> str:
        """Reference (measured) dimension annotation — a line + number that
        *shows* a size; it does not drive geometry (parametrize the geometry
        with Python variables instead).

        Two forms:

        • Bound to a sketch element — endpoints / value / target are derived
          from the element's CURRENT geometry, so the line tracks the shape
          when the script's parameters change::

              rect = sk.rectangle_centered(center=(0, 0), width=W, height=H)
              sk.dimension(rect)              # width (default for a rectangle)
              sk.dimension(rect, "height")

              c = sk.circle(center=(0, 0), radius=R)
              sk.dimension(c)                 # radius (default for a circle)
              sk.dimension(c, "diameter")

              ln = sk.line((0, 0), (L, 0))
              sk.dimension(ln)                # length

        • Two explicit points (``value`` auto = span unless given)::

              sk.dimension(from_=(0, 0), to=(W, 0))

        ``name`` is the script variable shown after the value, e.g. "65.00 (W)".
        When omitted it is auto-detected from the caller's variables (the one
        whose value equals the measured size); pass it explicitly to override.
        """
        if element is not None:
            frm, t, val, dim_type, target_idx = self._dim_from_element(element, kind)
            el = DimensionElement(
                **{"from": frm},
                to=t,
                value=val,
                dimension_type=dim_type,  # type: ignore[arg-type]
                target_element=target_idx,
                parameter_name=name if name is not None else _find_var_name(val),
            )
        else:
            if from_ is None or to is None:
                raise ValueError(
                    "dimension(): pass an element id, or both from_ and to."
                )
            p1, p2 = _pt(from_), _pt(to)
            val = float(value) if value is not None else math.hypot(p2.x - p1.x, p2.y - p1.y)
            el = DimensionElement(
                **{"from": p1}, to=p2, value=val,
                dimension_type=dimension_type,  # type: ignore[arg-type]
                parameter_name=name if name is not None else _find_var_name(val),
            )
        self._doc.elements.append(el)
        return el.id

    def _dim_from_element(
        self, element_id: str, kind: str | None
    ) -> tuple[Point2D, Point2D, float, str, int]:
        """Derive (from, to, value, dimension_type, target_index) for a
        dimension bound to a sketch element. ``kind`` selects which measurement;
        ``None`` picks the natural default per element type.

        The dimension LINE position is intentionally not set here — the vCAD
        runtime places it per ГОСТ 2.307 on load (10 мм from the contour, 7 мм
        between parallel lines); see refreshDimensions.ts. Keeping placement in
        one place avoids two copies of the rule drifting apart.
        """
        idx = self._idx(element_id)
        el = self._doc.elements[idx]
        et = el.type

        if et == "rectangle":
            c, w, h = el.corner, el.width, el.height
            k = kind or "width"
            if k == "width":
                return Point2D(x=c.x, y=c.y), Point2D(x=c.x + w, y=c.y), w, "linear", idx
            if k == "height":
                return Point2D(x=c.x, y=c.y), Point2D(x=c.x, y=c.y + h), h, "linear", idx
            raise ValueError(f"rectangle dimension kind must be 'width' or 'height', got {kind!r}")

        if et in ("circle", "arc"):
            c, r = el.center, el.radius
            k = kind or "radius"
            if k == "radius":
                return Point2D(x=c.x, y=c.y), Point2D(x=c.x + r, y=c.y), r, "radius", idx
            if k == "diameter":
                return Point2D(x=c.x - r, y=c.y), Point2D(x=c.x + r, y=c.y), 2 * r, "diameter", idx
            raise ValueError(f"{et} dimension kind must be 'radius' or 'diameter', got {kind!r}")

        if et in ("line", "slot"):
            s, e = el.start, el.end
            k = kind or "length"
            if k in ("length", "width"):
                val = math.hypot(e.x - s.x, e.y - s.y)
                return s, e, val, "linear", idx
            raise ValueError(f"{et} dimension kind must be 'length', got {kind!r}")

        raise ValueError(
            f"dimension(): can't auto-dimension element type {et!r}. "
            f"Use the explicit form dimension(from_=..., to=...)."
        )

    # ─── Element flagging ──────────────────────────────────────────────────

    def construction(self, *ids: str) -> None:
        """Mark elements (by id) as construction geometry."""
        current = self._doc.construction_ids or []
        for eid in ids:
            if eid not in current:
                current.append(eid)
        self._doc.construction_ids = current

    # ─── Constraints ──────────────────────────────────────────────────────

    def horizontal(self, element: str) -> None:
        self._add_constraint(HorizontalConstraint(element=self._idx(element)))

    def vertical(self, element: str) -> None:
        self._add_constraint(VerticalConstraint(element=self._idx(element)))

    def fixed(self, element: str) -> None:
        self._add_constraint(FixedConstraint(element=self._idx(element)))

    def parallel(self, e1: str, e2: str) -> None:
        self._add_constraint(ParallelConstraint(element1=self._idx(e1), element2=self._idx(e2)))

    def perpendicular(self, e1: str, e2: str) -> None:
        self._add_constraint(PerpendicularConstraint(element1=self._idx(e1), element2=self._idx(e2)))

    def equal(self, e1: str, e2: str) -> None:
        self._add_constraint(EqualConstraint(element1=self._idx(e1), element2=self._idx(e2)))

    def tangent(self, e1: str, e2: str) -> None:
        self._add_constraint(TangentConstraint(element1=self._idx(e1), element2=self._idx(e2)))

    def concentric(self, e1: str, e2: str) -> None:
        self._add_constraint(ConcentricConstraint(element1=self._idx(e1), element2=self._idx(e2)))

    def symmetric(self, e1: str, e2: str, axis: str) -> None:
        self._add_constraint(
            SymmetricConstraint(
                element1=self._idx(e1),
                element2=self._idx(e2),
                axis=self._idx(axis),
            )
        )

    def coincident(self, p1: PointSpec, p2: PointSpec) -> None:
        self._add_constraint(
            CoincidentConstraint(point1=self._pref(p1), point2=self._pref(p2))
        )

    def distance(self, p1: PointSpec, p2: PointSpec, value: float) -> None:
        self._add_constraint(
            DistanceConstraint(
                point1=self._pref(p1),
                point2=self._pref(p2),
                value=float(value),
            )
        )

    def angle(self, e1: str, e2: str, value: float) -> None:
        self._add_constraint(
            AngleConstraint(
                element1=self._idx(e1),
                element2=self._idx(e2),
                value=float(value),
            )
        )

    def radius(self, element: str, value: float) -> None:
        self._add_constraint(RadiusConstraint(element=self._idx(element), value=float(value)))

    def point_on_line(self, point: PointSpec, line: str) -> None:
        self._add_constraint(
            PointOnLineConstraint(point=self._pref(point), line=self._idx(line))
        )

    def point_on_circle(self, point: PointSpec, circle: str) -> None:
        self._add_constraint(
            PointOnCircleConstraint(point=self._pref(point), circle=self._idx(circle))
        )

    def midpoint(self, line1: str, line2: str) -> None:
        self._add_constraint(
            MidpointConstraint(line1=self._idx(line1), line2=self._idx(line2))
        )

    # ─── Introspection ─────────────────────────────────────────────────────

    @property
    def elements(self) -> list[SketchElement]:
        return self._doc.elements

    @property
    def constraints(self) -> list[SketchConstraint]:
        return self._doc.constraints or []

    def last(self) -> SketchElement | None:
        """Most recently appended element."""
        return self._doc.elements[-1] if self._doc.elements else None

    # ─── Internal: id/point resolution ────────────────────────────────────

    def _idx(self, element_id: str) -> int:
        """Resolve an element id to its current array index. Raises if the
        element doesn't exist yet — constraints must follow their elements
        in the script.
        """
        for i, el in enumerate(self._doc.elements):
            if el.id == element_id:
                return i
        raise ValueError(
            f"Unknown sketch element id {element_id!r}. Add the element "
            f"before referring to it from a constraint."
        )

    def _pref(self, spec: PointSpec) -> PointRef:
        """Convert a `(id, name|int)` spec or bare id into a PointRef."""
        if isinstance(spec, str):
            element_id, key = spec, 0
        else:
            element_id, key = spec[0], spec[1]
        idx = self._idx(element_id)
        if isinstance(key, int):
            return PointRef(element_index=idx, point_index=key)
        el_type = self._doc.elements[idx].type
        try:
            pidx = _POINT_NAME_INDEX[el_type][key]
        except KeyError as e:
            raise ValueError(
                f"Element type {el_type!r} has no named point {key!r}. "
                f"Pass an integer index, or use one of: "
                f"{sorted(_POINT_NAME_INDEX.get(el_type, {}).keys())}"
            ) from e
        return PointRef(element_index=idx, point_index=pidx)

    def _add_constraint(self, c: SketchConstraint) -> None:
        # Lazy-init so empty sketches don't carry an empty list through
        # serialization (preserves round-trip with wasm_vCAD's output).
        if self._doc.constraints is None:
            self._doc.constraints = []
        self._doc.constraints.append(c)


# ─── Body builder ───────────────────────────────────────────────────────────


class Body:
    """Wrapper around a BodyDoc. Phase 1 only knows how to attach a single
    sketch feature; extrude/cut land in Phase 3.
    """

    def __init__(self, doc: BodyDoc) -> None:
        self._doc = doc

    @property
    def id(self) -> str:
        return self._doc.id

    @property
    def name(self) -> str:
        return self._doc.name

    @property
    def color(self) -> str | None:
        """Per-body display colour (hex "#rrggbb"), or None for the default."""
        return self._doc.color

    @color.setter
    def color(self, value: str | None) -> None:
        self._doc.color = value

    def set_color(self, value: str | None) -> "Body":
        """Set the body's display colour (hex "#rrggbb"); None resets to the
        default. Returns self for chaining."""
        self._doc.color = value
        return self

    def set_material(self, material: str | None = None, *, density: float | None = None) -> "Body":
        """Set the body's material (for mass/dynamics). Pass a material id (e.g.
        "steel", "aluminum" — see vCAD's material catalogue) OR a custom
        ``density`` in kg/m³ (which overrides the material). The viewer derives
        mass = density · volume. Returns self for chaining."""
        if density is not None:
            self._doc.density = float(density)
            self._doc.material = None
        else:
            self._doc.material = material
            self._doc.density = None
        return self

    def start_sketch(
        self,
        plane: Plane = Plane.XY,
        offset: float = 0.0,
        face_coord_system: dict | None = None,
    ) -> Sketch:
        """Append a sketch feature to the body and return a Sketch builder."""
        sk = SketchDoc(plane=plane, offset=offset)
        if face_coord_system is not None:
            # Coerce a plain dict into the model so keys are validated and
            # serialization is clean (raw-dict assignment warns + risks a
            # mis-typed key silently surviving the round-trip).
            sk.face_coord_system = (
                face_coord_system
                if isinstance(face_coord_system, FaceCoordSystem)
                else FaceCoordSystem(**face_coord_system)
            )
        feat = Feature(type="sketch", sketch=sk, transform=Transform())
        self._doc.features.append(feat)
        return Sketch(sk, feature_id=feat.id)

    # ─── Primitives (built-in solids) ─────────────────────────────────────

    def cube(
        self,
        width: float = 1.0,
        height: float = 1.0,
        depth: float = 1.0,
        position: tuple[float, float, float] = (0.0, 0.0, 0.0),
        rotation: tuple[float, float, float] = (0.0, 0.0, 0.0),
        scale: tuple[float, float, float] = (1.0, 1.0, 1.0),
    ) -> str:
        """Append a cube primitive. Returns the feature id."""
        return self._add_primitive(
            Primitive(type="cube", width=width, height=height, depth=depth),
            position=position, rotation=rotation, scale=scale,
        )

    def cylinder(
        self,
        radius: float = 0.5,
        height: float = 1.0,
        position: tuple[float, float, float] = (0.0, 0.0, 0.0),
        rotation: tuple[float, float, float] = (0.0, 0.0, 0.0),
        scale: tuple[float, float, float] = (1.0, 1.0, 1.0),
    ) -> str:
        return self._add_primitive(
            Primitive(type="cylinder", radius=radius, height=height),
            position=position, rotation=rotation, scale=scale,
        )

    def sphere(
        self,
        radius: float = 0.5,
        position: tuple[float, float, float] = (0.0, 0.0, 0.0),
        rotation: tuple[float, float, float] = (0.0, 0.0, 0.0),
        scale: tuple[float, float, float] = (1.0, 1.0, 1.0),
    ) -> str:
        return self._add_primitive(
            Primitive(type="sphere", radius=radius),
            position=position, rotation=rotation, scale=scale,
        )

    def cone(
        self,
        radius: float = 0.5,
        height: float = 1.0,
        position: tuple[float, float, float] = (0.0, 0.0, 0.0),
        rotation: tuple[float, float, float] = (0.0, 0.0, 0.0),
        scale: tuple[float, float, float] = (1.0, 1.0, 1.0),
    ) -> str:
        return self._add_primitive(
            Primitive(type="cone", radius=radius, height=height),
            position=position, rotation=rotation, scale=scale,
        )

    # ─── Extrude / Cut ────────────────────────────────────────────────────

    def extrude(
        self,
        sketch: Sketch | str,
        height: float,
        height_backward: float = 0.0,
        draft_angle: float = 0.0,
        taper: float | None = None,
        twist_angle: float = 0.0,
        is_cut: bool = False,
    ) -> str:
        """Extrude (or cut, if ``is_cut=True``) the given sketch. Accepts a
        Sketch builder or a raw sketch feature id.

        ``taper`` is an optional cross-section scale at the end face:
        1.0 (or None) leaves a straight prism, <1 narrows toward the
        top, >1 flares outward. Implemented via replicad's
        ``extrusionProfile.endFactor`` — a geometric axial scaling, NOT
        a true draft angle. Use this until OCCT's
        ``BRepOffsetAPI_DraftAngle`` is exposed in
        ``replicad-opencascadejs``. ``draft_angle`` is kept as a no-op
        placeholder for the same reason.

        Note: on disk both add-extrude and cut have ``type: 'extrude'``;
        the ``cut`` boolean flag distinguishes them. wasm_vCAD's loader
        only recognises that exact shape — emitting ``type: 'cut'`` makes
        the feature silently disappear on load.
        """
        sid = sketch.id if isinstance(sketch, Sketch) else sketch
        extra: dict[str, float] = {}
        if taper is not None:
            extra["taper"] = float(taper)
        # twist_angle (deg) twists the section about the extrude axis over the
        # height — e.g. helical gears (косозубая). Emitted only when non-zero so
        # straight extrudes stay diff-free. Applied via replicad's twistExtrude.
        if twist_angle:
            extra["twist_angle"] = float(twist_angle)
        feat = Feature(
            type="extrude",
            sketch_id=sid,
            height=float(height),
            height_backward=float(height_backward),
            draft_angle=float(draft_angle),
            cut=bool(is_cut),
            **extra,
        )
        self._doc.features.append(feat)
        return feat.id

    def cut(
        self,
        sketch: Sketch | str,
        height: float,
        height_backward: float = 0.0,
        draft_angle: float = 0.0,
        taper: float | None = None,
    ) -> str:
        """Convenience: same as extrude(..., is_cut=True)."""
        return self.extrude(
            sketch, height, height_backward=height_backward,
            draft_angle=draft_angle, taper=taper, is_cut=True,
        )

    # ─── Sweep (выдавливание/вырез по траектории) ─────────────────────────

    def sweep(
        self,
        profile: Sketch | str,
        path: Sketch | str,
        *,
        twist_angle: float = 0.0,
        frenet: bool = False,
        is_cut: bool = False,
    ) -> str:
        """Sweep (or cut, if ``is_cut=True``) a profile sketch along a path
        sketch. Both arguments accept either a Sketch builder or a raw
        sketch feature id; the path sketch should contain an open chain
        (line / arc / open polyline / spline) that lives in its own sketch
        plane (commonly perpendicular to the profile plane).

        On disk both add-sweep and sweep-cut have ``type: 'sweep'`` and the
        ``cut`` boolean distinguishes them — same convention as extrude/cut.

        ``twist_angle`` (degrees) and ``frenet`` are forwarded to the engine
        but ``twist_angle`` is not yet honoured by the current replicad
        replay (recorded for future raw-OCCT path).
        """
        prof_id = profile.id if isinstance(profile, Sketch) else profile
        path_id = path.id if isinstance(path, Sketch) else path
        feat = Feature(
            type="sweep",
            sketch_id=prof_id,
            path_sketch_id=path_id,
            twist_angle=float(twist_angle),
            frenet=bool(frenet),
            cut=bool(is_cut),
        )
        self._doc.features.append(feat)
        return feat.id

    def sweep_cut(
        self,
        profile: Sketch | str,
        path: Sketch | str,
        *,
        twist_angle: float = 0.0,
        frenet: bool = False,
    ) -> str:
        """Convenience: same as ``sweep(..., is_cut=True)``."""
        return self.sweep(
            profile, path,
            twist_angle=twist_angle, frenet=frenet, is_cut=True,
        )

    def sweep_helix(
        self,
        profile: Sketch | str,
        *,
        pitch: float,
        height: float,
        radius: float,
        center: tuple[float, float, float] = (0.0, 0.0, 0.0),
        direction: tuple[float, float, float] = (0.0, 0.0, 1.0),
        lefthand: bool = False,
        twist_angle: float = 0.0,
        frenet: bool = False,
        is_cut: bool = False,
    ) -> str:
        """Sweep the profile along a programmatic helix spine. Use this
        instead of authoring a 3D helical path sketch (sketches are flat
        in vCAD). vcad replay calls replicad's ``sketchHelix(pitch,
        height, radius, center, direction, lefthand)`` to build the spine.

        Defaults wind the helix anti-clockwise (right-hand thread) around
        +Z through the origin.
        """
        prof_id = profile.id if isinstance(profile, Sketch) else profile
        helix = {
            "pitch": float(pitch),
            "height": float(height),
            "radius": float(radius),
            "center": [float(center[0]), float(center[1]), float(center[2])],
            "direction": [float(direction[0]), float(direction[1]), float(direction[2])],
            "lefthand": bool(lefthand),
        }
        feat = Feature(
            type="sweep",
            sketch_id=prof_id,
            helix=helix,
            twist_angle=float(twist_angle),
            frenet=bool(frenet),
            cut=bool(is_cut),
        )
        self._doc.features.append(feat)
        return feat.id

    # ─── Revolve ──────────────────────────────────────────────────────────

    def revolve(
        self,
        sketch: Sketch | str,
        axis_start: PointLike,
        axis_end: PointLike,
        angle: float = 360.0,
        segments: int = 64,
        cut: bool = False,
    ) -> str:
        """Revolve the sketch profile around the given 2D axis. `angle` in
        degrees; full revolution is 360.
        """
        sid = sketch.id if isinstance(sketch, Sketch) else sketch
        a = _pt(axis_start)
        b = _pt(axis_end)
        feat = Feature(
            type="revolve",
            sketch_id=sid,
            axis_start=a,
            axis_end=b,
            angle=float(angle),
            segments=int(segments),
            cut=bool(cut),
        )
        self._doc.features.append(feat)
        return feat.id

    # ─── Fillet / Chamfer 3D ──────────────────────────────────────────────
    #
    # vCAD picks edges by clicking in the viewport — we don't know the
    # edge endpoints from outside the OCCT replay. These methods accept
    # raw (start, end) tuples so you can copy them from an existing
    # scene file or compute them analytically.

    def fillet_3d(
        self,
        edges: list[tuple[tuple[float, float, float], tuple[float, float, float]]] | None = None,
        radius: float | None = None,
        segments: int = 8,
        *,
        faces: list[tuple[tuple[float, float, float], tuple[float, float, float]]] | None = None,
    ) -> str:
        """Round edges. Give explicit `edges` (vertex pairs) and/or `faces`
        (each a (point-on-face, outward-normal) anchor) — a face selector
        rounds ALL of that face's edges, compacting a whole loop into one ref.
        """
        if radius is None:
            raise ValueError("fillet_3d: radius is required")
        params = Fillet3DParams(
            edge_vertices=[EdgeVertices(start=s, end=e) for s, e in (edges or [])],
            radius=float(radius),
            segments=int(segments),
            face_selectors=[FaceAnchor(point=p, normal=n) for p, n in (faces or [])],
        )
        feat = Feature(type="fillet_3d", fillet_3d=params.model_dump(mode="json"))
        self._doc.features.append(feat)
        return feat.id

    def chamfer_3d(
        self,
        edges: list[tuple[tuple[float, float, float], tuple[float, float, float]]] | None = None,
        distance1: float | None = None,
        distance2: float | None = None,
        ref_normal: tuple[float, float, float] | None = None,
        *,
        faces: list[tuple[tuple[float, float, float], tuple[float, float, float]]] | None = None,
    ) -> str:
        """Bevel edges. `distance2=None` → symmetric. Give explicit `edges`
        and/or `faces` ((point, normal) anchors) — a face selector bevels ALL
        of that face's edges. `distance1` is required.
        """
        if distance1 is None:
            raise ValueError("chamfer_3d: distance1 is required")
        d2 = float(distance2) if distance2 is not None else float(distance1)
        params = Chamfer3DParams(
            edge_vertices=[EdgeVertices(start=s, end=e) for s, e in (edges or [])],
            distance1=float(distance1),
            distance2=d2,
            ref_normal=ref_normal,
            face_selectors=[FaceAnchor(point=p, normal=n) for p, n in (faces or [])],
        )
        feat = Feature(
            type="chamfer_3d",
            chamfer_3d=params.model_dump(mode="json", exclude_none=True),
        )
        self._doc.features.append(feat)
        return feat.id

    def shell(
        self,
        thickness: float,
        faces_to_remove: list[
            tuple[tuple[float, float, float], tuple[float, float, float]]
        ] | None = None,
    ) -> str:
        """Hollow the current body to ``thickness``.

        ``faces_to_remove`` lists faces to pierce, each as
        ``(point, normal)`` where ``point`` is on the face (centroid is
        typical) and ``normal`` is the outward face normal. Empty / None
        produces a closed shell — same outer geometry, hollow interior
        (rarely useful on its own, usually you want at least one open
        face for a cup/box).
        """
        anchors = [FaceAnchor(point=p, normal=n) for p, n in (faces_to_remove or [])]
        params = ShellParams(thickness=float(thickness), faces_to_remove=anchors)
        feat = Feature(type="shell", shell=params.model_dump(mode="json"))
        self._doc.features.append(feat)
        return feat.id

    def scale(
        self,
        x: float,
        y: float | None = None,
        z: float | None = None,
        *,
        center: tuple[float, float, float] | None = None,
    ) -> str:
        """Resize the current solid by a factor.

        ``body.scale(2)`` doubles the size uniformly. Per-axis factors
        (``body.scale(2, 1.5, 1)``) are accepted for forward-compat, but
        vCAD only honours *uniform* scaling today (the non-uniform B-Rep
        transform isn't in the current OCCT build) — a non-uniform triple
        is clamped to the ``x`` factor on replay.

        Scaling is about ``center`` (a fixed point); when omitted the
        body's bounding-box centre is used so the part stays in place.
        """
        yy = x if y is None else y
        zz = x if z is None else z
        if not (x > 0 and yy > 0 and zz > 0):
            raise ValueError(f"scale: factors must be > 0, got ({x}, {yy}, {zz})")
        params = ScaleBodyParams(x=float(x), y=float(yy), z=float(zz), center=center)
        feat = Feature(
            type="scale_body",
            scale_body=params.model_dump(mode="json", exclude_none=True),
        )
        self._doc.features.append(feat)
        return feat.id

    def mirror(
        self,
        plane: str = "XZ",
        *,
        origin: tuple[float, float, float] | None = None,
        normal: tuple[float, float, float] | None = None,
        merge: bool = True,
    ) -> str:
        """Reflect the current solid across ``plane``.

        ``plane='XY'|'XZ'|'YZ'`` — axis-aligned, through origin.
        ``plane='CUSTOM'`` — pass ``origin`` + ``normal`` for an
        arbitrary plane.

        ``merge=True`` (default) fuses the mirrored copy with the
        original (symmetric whole from a half-design). ``merge=False``
        replaces the original with its reflection.
        """
        if plane not in ("XY", "XZ", "YZ", "CUSTOM"):
            raise ValueError(f"mirror: plane must be XY/XZ/YZ/CUSTOM, got {plane!r}")
        if plane == "CUSTOM" and (origin is None or normal is None):
            raise ValueError("mirror with plane='CUSTOM' requires origin + normal")

        params = MirrorParams(
            plane=plane,  # type: ignore[arg-type]
            origin=origin,
            normal=normal,
            merge=merge,
        )
        feat = Feature(
            type="mirror",
            mirror=params.model_dump(mode="json", exclude_none=True),
        )
        self._doc.features.append(feat)
        return feat.id

    def linear_pattern(
        self,
        direction: tuple[float, float, float],
        count: int,
        spacing: float,
        *,
        merge: bool = True,
    ) -> str:
        """Repeat the current solid ``count`` times along ``direction``.

        ``count`` includes the original at index 0 — count=5 makes 5
        copies total (4 new + the original). ``direction`` doesn't
        need to be unit-length; it's normalised. ``spacing`` is the
        centre-to-centre distance in mm.
        """
        if count < 1:
            raise ValueError(f"linear_pattern: count must be ≥ 1, got {count}")
        params = LinearPattern3DParams(
            direction=direction,
            count=int(count),
            spacing=float(spacing),
            merge=merge,
        )
        feat = Feature(
            type="linear_pattern_3d",
            linear_pattern_3d=params.model_dump(mode="json"),
        )
        self._doc.features.append(feat)
        return feat.id

    def circular_pattern(
        self,
        axis_point: tuple[float, float, float],
        axis_direction: tuple[float, float, float],
        count: int,
        step_angle_deg: float,
        *,
        merge: bool = True,
    ) -> str:
        """Repeat the current solid ``count`` times around an axis.

        Axis = ``axis_point`` (any point on it) + ``axis_direction``.
        ``count`` includes the original; copies sit at
        ``step_angle_deg * i`` for i = 1..count-1.

        For a full-circle pattern of N items: ``count=N``,
        ``step_angle_deg=360 / N``.
        """
        if count < 1:
            raise ValueError(f"circular_pattern: count must be ≥ 1, got {count}")
        params = CircularPattern3DParams(
            axis_point=axis_point,
            axis_direction=axis_direction,
            count=int(count),
            step_angle_deg=float(step_angle_deg),
            merge=merge,
        )
        feat = Feature(
            type="circular_pattern_3d",
            circular_pattern_3d=params.model_dump(mode="json"),
        )
        self._doc.features.append(feat)
        return feat.id

    def loft(
        self,
        sections: list["Sketch | str"],
        *,
        ruled: bool = False,
    ) -> str:
        """Interpolate a solid between cross-section sketches.

        ``sections`` lists ≥ 2 sketches in order (start → end). Each
        item may be a ``Sketch`` builder (from ``start_sketch``) or a
        raw sketch feature id. Each sketch should live on its own plane
        and contain one closed contour.

        ``ruled=True`` produces a piecewise-linear surface between
        adjacent sections; default ``False`` is a smooth interpolation.
        """
        if len(sections) < 2:
            raise ValueError(f"loft: need ≥ 2 cross-section sketches, got {len(sections)}")
        ids: list[str] = []
        for s in sections:
            if isinstance(s, Sketch):
                ids.append(s.id)
            elif isinstance(s, str):
                ids.append(s)
            else:
                raise TypeError(f"loft: section must be Sketch or sketch-id str, got {type(s).__name__}")
        params = LoftParams(loft_sketch_ids=ids, ruled=bool(ruled))
        feat = Feature(type="loft", loft=params.model_dump(mode="json"))
        self._doc.features.append(feat)
        return feat.id

    def import_step(self, step_path: str | Path) -> str:
        """Import an external CAD model from a STEP file.

        Reads the file at ``step_path``, base64-encodes the contents,
        and records a ``step_import`` feature on this body. On replay,
        the engine decodes the bytes and calls replicad's
        ``importSTEP`` — the resulting shape becomes the body's new
        anchor geometry (subsequent features modify it).

        The original filename is remembered in ``source_path`` for
        debugging. The actual bytes live entirely inside the scene
        JSON, so the saved file is self-contained.
        """
        p = Path(step_path)
        if not p.is_file():
            raise FileNotFoundError(f"import_step: STEP file not found: {p}")
        raw = p.read_bytes()
        b64 = base64.b64encode(raw).decode("ascii")
        params = StepImportParams(content_b64=b64, source_path=p.name)
        feat = Feature(
            type="step_import",
            step_import=params.model_dump(mode="json"),
        )
        self._doc.features.append(feat)
        return feat.id

    # ─── Named faces / edges ──────────────────────────────────────────────
    #
    # Mirrors the RMB → "Имя…" workflow in vCAD's main mode. The label is
    # anchored geometrically (point + normal in world space) so it tracks
    # the actual face / edge across re-tessellation and feature edits — the
    # same matching scheme `replicad` uses for fillet/chamfer edges.
    #
    # Assembly mates can then reference the face by name via
    # `Assembly.mate_*((inst, "your_name"), ...)` instead of OCCT hashCodes.

    def name_face(
        self,
        *,
        name: str,
        point: tuple[float, float, float],
        normal: tuple[float, float, float],
        color: str | None = None,
        entity_id: str | None = None,
    ) -> str:
        """Tag a face on this body with a stable label. `point` is any
        point on the face (centroid is typical), `normal` is the outward
        face normal. `color` is an optional CSS string; when omitted vCAD
        derives a pastel tint from `name`. Returns the entity id.
        """
        entity = NamedEntity(
            name=name,
            kind="face",
            color=color,
            anchor=NamedEntityAnchor(point=point, normal=normal),
        )
        if entity_id is not None:
            entity.id = entity_id
        return self._append_named_entity(entity)

    def name_edge(
        self,
        *,
        name: str,
        start: tuple[float, float, float],
        end: tuple[float, float, float],
        normal: tuple[float, float, float] = (0.0, 0.0, 1.0),
        color: str | None = None,
        entity_id: str | None = None,
    ) -> str:
        """Tag an edge on this body with a stable label. `start`/`end` are
        the edge vertices, `normal` the adjacent face normal (any one of
        the two adjacent faces — used as a tie-breaker for the match).
        """
        entity = NamedEntity(
            name=name,
            kind="edge",
            color=color,
            anchor=NamedEntityAnchor(point=start, normal=normal, endpoint=end),
        )
        if entity_id is not None:
            entity.id = entity_id
        return self._append_named_entity(entity)

    @property
    def named_entities(self) -> list[NamedEntity]:
        return list(self._doc.named_entities or [])

    def _append_named_entity(self, entity: NamedEntity) -> str:
        # Block duplicate names within one body — they break the
        # `(inst, "name")` lookup in Assembly mates by making the match
        # ambiguous (`_find_named_face` takes the first hit).
        existing = self._doc.named_entities or []
        for e in existing:
            if e.name == entity.name:
                raise ValueError(
                    f"Body already has a NamedEntity called {entity.name!r}. "
                    "Names must be unique within a body."
                )
        if self._doc.named_entities is None:
            self._doc.named_entities = []
        self._doc.named_entities.append(entity)
        return entity.id

    # ─── Internal: primitive helper ───────────────────────────────────────

    def _add_primitive(
        self,
        primitive: Primitive,
        *,
        position: tuple[float, float, float],
        rotation: tuple[float, float, float],
        scale: tuple[float, float, float],
    ) -> str:
        # vCAD's on-disk format uses `base_primitive` for the legacy
        # cube/cylinder/sphere/cone tag (in-memory type is `primitive`).
        # Emitting plain `primitive` makes the desktop loader skip the
        # feature silently — see sceneSerializer.deserializeFeatures.
        feat = Feature(
            type="base_primitive",
            primitive=primitive,
            transform=Transform(position=position, rotation=rotation, scale=scale),
        )
        self._doc.features.append(feat)
        return feat.id


# ─── Scene builder ──────────────────────────────────────────────────────────


# ─── Assembly builder ───────────────────────────────────────────────────────


# Identifies one face of an instance for a mate. Accepts:
#   - a FaceRefDoc directly
#   - (PartInstance|instance_id, int) — OCCT hashCode (legacy, brittle
#     across re-tessellations, must be read off vCAD's MateDialog)
#   - (PartInstance|instance_id, str) — NamedEntity name authored on
#     the source part's body. The Assembly resolves the name to a
#     `namedEntityId` at mate-creation time by reading the referenced
#     `.part.json` from `assembly.scenes_dir`; vCAD then re-binds it
#     to the current faceId at solve time.
FaceLike: TypeAlias = Union[
    FaceRefDoc,
    tuple["PartInstance", int],
    tuple["PartInstance", str],
    tuple[str, int],
    tuple[str, str],
]

# Same shape as ``FaceLike`` but for edges. Strings resolve against the
# source part's NamedEntity table (``kind="edge"`` entries); ints are
# raw OCCT hashCode references.
EdgeLike: TypeAlias = Union[
    "EdgeRefDoc",
    tuple["PartInstance", int],
    tuple["PartInstance", str],
    tuple[str, int],
    tuple[str, str],
]

# Vertex equivalent. vcad-py's NamedEntity has no ``kind="vertex"`` yet,
# so the string form is reserved for future use — for now only ints
# (OCCT vertex hashCodes) resolve cleanly.
VertexLike: TypeAlias = Union[
    "VertexRefDoc",
    tuple["PartInstance", int],
    tuple[str, int],
]


class PartInstance:
    """Handle returned by Assembly.import_part(). `id` is what mates
    reference; the underlying PartInstanceDoc lives inside the assembly's
    model and is mutated in place."""

    def __init__(self, doc: PartInstanceDoc) -> None:
        self._doc = doc

    @property
    def id(self) -> str:
        return self._doc.id

    @property
    def name(self) -> str | None:
        return self._doc.name

    @property
    def path(self) -> str:
        return self._doc.partRef.path

    def set_transform(
        self,
        translation: tuple[float, float, float] | None = None,
        rotation: tuple[float, float, float, float] | None = None,
    ) -> None:
        """Replace the instance's transform fields. Identity components stay
        identity when omitted."""
        if translation is not None:
            self._doc.transform = Transform3D(
                translation=translation,
                rotation=self._doc.transform.rotation,
            )
        if rotation is not None:
            self._doc.transform = Transform3D(
                translation=self._doc.transform.translation,
                rotation=rotation,
            )

    def fix(self) -> None:
        """Anchor this instance in place. Equivalent to a 'fix' mate."""
        self._doc.fixed = True

    def face_at(
        self,
        point: tuple[float, float, float],
        normal: tuple[float, float, float],
    ) -> FaceRefDoc:
        """Reference a face by its part-local centroid + outward normal.

        vCAD re-resolves it to the current face geometrically (nearest
        centroid/aligned normal) at solve time, so the mate survives OCCT
        hashCode churn across re-tessellation — unlike the raw ``(inst, int)``
        hashCode form. This is what the decompiler emits for unnamed faces; for
        labelled faces prefer the readable ``(inst, "name")`` form.
        """
        return FaceRefDoc(
            instanceId=self.id,
            faceId=0,
            geom=FaceGeomDoc(centroid=tuple(point), normal=tuple(normal)),
        )


def _resolve_face(
    face: FaceLike,
    scenes_dir: Path | None,
    inst_path_lookup: dict[str, str],
) -> FaceRefDoc:
    if isinstance(face, FaceRefDoc):
        return face
    inst, face_key = face
    instance_id = inst.id if isinstance(inst, PartInstance) else inst

    # Numeric → legacy OCCT hashCode reference.
    if isinstance(face_key, int):
        return FaceRefDoc(instanceId=instance_id, faceId=int(face_key))

    # String → NamedEntity name lookup against the source part file.
    if scenes_dir is None:
        raise ValueError(
            "Using a face name in a mate requires Assembly(scenes_dir=...) "
            "so the part's NamedEntity ids can be resolved. Pass the path "
            "to your wasm_vCAD/scenes/ directory."
        )
    part_path = inst_path_lookup.get(instance_id)
    if part_path is None:
        raise ValueError(
            f"Unknown instance {instance_id!r}. Call import_part(...) before "
            "referring to it from a mate."
        )
    named = _find_named_face(scenes_dir / part_path, face_key)
    if named is None:
        raise ValueError(
            f"Part {part_path!r} has no face NamedEntity called {face_key!r}. "
            "Label the face in vCAD (RMB → Имя…) first."
        )
    # faceId 0 is the placeholder — vCAD's resolver prefers
    # namedEntityId and re-binds to the current hashCode at solve time.
    # bodyId is mandatory: without it vCAD's namedFaceMaps lookup
    # (keyed by instanceId+bodyId) misses and the mate gets silently
    # dropped at solve time (cab/cargo would fall through chassis).
    return FaceRefDoc(
        instanceId=instance_id,
        bodyId=named["bodyId"],
        faceId=0,
        namedEntityId=named["id"],
        namedEntityName=named["name"],
    )


def _resolve_edge(
    edge: EdgeLike,
    scenes_dir: Path | None,
    inst_path_lookup: dict[str, str],
) -> EdgeRefDoc:
    """Mirror of ``_resolve_face`` for edges. String form looks up
    ``NamedEntity`` rows of ``kind="edge"`` in the source part."""
    if isinstance(edge, EdgeRefDoc):
        return edge
    inst, edge_key = edge
    instance_id = inst.id if isinstance(inst, PartInstance) else inst

    if isinstance(edge_key, int):
        return EdgeRefDoc(instanceId=instance_id, edgeId=int(edge_key))

    if scenes_dir is None:
        raise ValueError(
            "Using an edge name in a mate requires Assembly(scenes_dir=...) "
            "so the part's NamedEntity ids can be resolved."
        )
    part_path = inst_path_lookup.get(instance_id)
    if part_path is None:
        raise ValueError(
            f"Unknown instance {instance_id!r}. Call import_part(...) before "
            "referring to it from a mate."
        )
    named = _find_named_edge(scenes_dir / part_path, edge_key)
    if named is None:
        raise ValueError(
            f"Part {part_path!r} has no edge NamedEntity called {edge_key!r}. "
            "Label the edge in vCAD (RMB → Имя…) first."
        )
    return EdgeRefDoc(
        instanceId=instance_id,
        bodyId=named["bodyId"],
        edgeId=0,
        namedEntityId=named["id"],
        namedEntityName=named["name"],
    )


def _resolve_vertex(
    vertex: VertexLike,
    inst_path_lookup: dict[str, str],
) -> VertexRefDoc:
    """Vertex resolver. vcad-py has no ``kind="vertex"`` NamedEntity yet,
    so only int / VertexRefDoc inputs are accepted — string lookup
    raises with a hint about where to label the vertex once the schema
    grows that support."""
    if isinstance(vertex, VertexRefDoc):
        return vertex
    inst, vertex_key = vertex
    instance_id = inst.id if isinstance(inst, PartInstance) else inst
    if isinstance(vertex_key, int):
        return VertexRefDoc(instanceId=instance_id, vertexId=int(vertex_key))
    raise ValueError(
        "Named-vertex references are not supported yet (NamedEntity has "
        "no kind='vertex'). Use the integer hashCode form for now."
    )


def _find_named_face(part_path: Path, name: str) -> dict[str, str] | None:
    """Scan a `.part.json` file for a face-kind NamedEntity with the
    given name. Returns its id + name + bodyId, or None when missing.
    Scans all bodies in the part; first match wins.
    """
    return _find_named_entity(part_path, name, kind="face")


def _find_named_edge(part_path: Path, name: str) -> dict[str, str] | None:
    """Edge equivalent of ``_find_named_face`` — looks up an
    ``edge``-kind NamedEntity row."""
    return _find_named_entity(part_path, name, kind="edge")


def _find_named_entity(
    part_path: Path, name: str, *, kind: str,
) -> dict[str, str] | None:
    if not part_path.is_file():
        raise FileNotFoundError(
            f"Part file not found: {part_path}. Check Assembly(scenes_dir=...)"
        )
    raw = json.loads(part_path.read_text(encoding="utf-8"))
    # Accept the `.part.json` wrapper as well as bare scene JSON.
    scene = raw["scene"] if isinstance(raw, dict) and raw.get("kind") == "part" else raw
    for body in scene.get("bodies", []):
        for ne in body.get("named_entities", []) or []:
            if ne.get("kind") == kind and ne.get("name") == name:
                return {"id": ne["id"], "name": ne["name"], "bodyId": body["id"]}
    return None


class Assembly:
    """`.asm.json` builder.

    Workflow mirrors what AssemblyMode does in vCAD:
      1. `import_part(path)` — drops one instance of a part document.
      2. `mate_*(...)` — adds a constraint between two instances.
      3. `save("foo.asm.json")` — emits the document; vCAD will replay
         each part on load and run the OndselSolver against the mates.

    Face refs use OCCT `face.hashCode` values; Python can't compute them
    from the .part.json alone (they're produced by replicad's mesher).
    Read them from vCAD's MateDialog output ("Part.face[8570185]") or
    just open the resulting .asm.json in vCAD and add mates by clicking.
    """

    def __init__(
        self,
        name: str | None = None,
        scenes_dir: str | Path | None = None,
    ) -> None:
        """`scenes_dir` is the absolute path to wasm_vCAD/scenes/. It's
        only required when mates reference faces by NamedEntity name
        (`(inst, "shaft_top")`); numeric `faceId` mates work without it.
        """
        self._doc = AssemblyDoc(name=name)
        self._scenes_dir: Path | None = Path(scenes_dir) if scenes_dir else None

    @property
    def name(self) -> str | None:
        return self._doc.name

    # ─── Instances ────────────────────────────────────────────────────────

    def import_part(
        self,
        path: str,
        name: str | None = None,
        fixed: bool = False,
        translation: tuple[float, float, float] = (0.0, 0.0, 0.0),
        rotation: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 1.0),
    ) -> PartInstance:
        """Add one instance of a part. `path` is the .part.json filename
        inside the project's scenes/ directory — vCAD resolves it on load."""
        doc = PartInstanceDoc(
            partRef=PartRef(path=path),
            transform=Transform3D(translation=translation, rotation=rotation),
            fixed=True if fixed else None,
            name=name,
        )
        self._doc.instances.append(doc)
        return PartInstance(doc)

    @property
    def instances(self) -> list[PartInstance]:
        return [PartInstance(d) for d in self._doc.instances]

    @property
    def mates(self) -> list[Mate]:
        return list(self._doc.mates)

    # ─── Mates ────────────────────────────────────────────────────────────

    def mate_fix(self, instance: PartInstance | str) -> str:
        """Pin one instance in place via a 'fix' mate. (Equivalent to
        ``instance.fix()`` but emits a Mate rather than the `fixed` flag.)
        Returns the mate id."""
        iid = instance.id if isinstance(instance, PartInstance) else instance
        mate = FixMate(instanceId=iid)
        self._doc.mates.append(mate)
        return mate.id

    def _instance_path_lookup(self) -> dict[str, str]:
        """instanceId → part .part.json path. Used to find the part
        file when resolving face names."""
        return {d.id: d.partRef.path for d in self._doc.instances}

    def mate_coincident(self, face_a: FaceLike, face_b: FaceLike, flip: bool = False) -> str:
        """Coincident face mate (planes flush, anti-parallel normals by
        default — set ``flip=True`` for parallel normals)."""
        lookup = self._instance_path_lookup()
        mate = CoincidentMate(
            faceA=_resolve_face(face_a, self._scenes_dir, lookup),
            faceB=_resolve_face(face_b, self._scenes_dir, lookup),
            flip=True if flip else None,
        )
        self._doc.mates.append(mate)
        return mate.id

    def mate_distance(self, face_a: FaceLike, face_b: FaceLike, value: float) -> str:
        """Distance face mate: planes parallel, separated by ``value`` (mm)."""
        lookup = self._instance_path_lookup()
        mate = DistanceMate(
            faceA=_resolve_face(face_a, self._scenes_dir, lookup),
            faceB=_resolve_face(face_b, self._scenes_dir, lookup),
            value=float(value),
        )
        self._doc.mates.append(mate)
        return mate.id

    def mate_concentric(self, face_a: FaceLike, face_b: FaceLike) -> str:
        """Concentric face mate: axes of two cylindrical faces coincide
        (slide-along + rotate-around stay free). Both faces must be
        cylindrical surfaces in vCAD."""
        lookup = self._instance_path_lookup()
        mate = ConcentricMate(
            faceA=_resolve_face(face_a, self._scenes_dir, lookup),
            faceB=_resolve_face(face_b, self._scenes_dir, lookup),
        )
        self._doc.mates.append(mate)
        return mate.id

    def mate_revolute(self, face_a: FaceLike, face_b: FaceLike) -> str:
        """Revolute (hinge) mate: like concentric, but the axial slide is
        LOCKED — a true 1-DOF pin (only rotation about the shared axis stays
        free). Both faces must be cylindrical. Use this for hinges/linkages
        so a motor drives it directly; multi-joint mechanisms then need no
        coincident plane-lock to kill the axial slide a concentric leaves."""
        lookup = self._instance_path_lookup()
        mate = RevoluteMate(
            faceA=_resolve_face(face_a, self._scenes_dir, lookup),
            faceB=_resolve_face(face_b, self._scenes_dir, lookup),
        )
        self._doc.mates.append(mate)
        return mate.id

    def mate_prismatic(self, face_a: FaceLike, face_b: FaceLike) -> str:
        """Prismatic (slider) mate: like concentric, but rotation is LOCKED —
        a true 1-DOF slider (only the axial slide stays free), the inverse
        of mate_revolute. Both faces must be cylindrical."""
        lookup = self._instance_path_lookup()
        mate = PrismaticMate(
            faceA=_resolve_face(face_a, self._scenes_dir, lookup),
            faceB=_resolve_face(face_b, self._scenes_dir, lookup),
        )
        self._doc.mates.append(mate)
        return mate.id

    def mate_tangent(
        self, face_a: FaceLike, face_b: FaceLike, side: int | None = None,
    ) -> str:
        """Tangent mate: a cylindrical face rests on a planar face — the
        axis stays parallel to the plane at distance = radius (the surface
        just touches), like a rod on a table. One face must be cylindrical,
        the other planar; the order doesn't matter.

        ``side`` picks which side of the plane the part rests on: +1 along
        the face normal, -1 against it. Default (None) — whichever side the
        part is nearer when solving."""
        lookup = self._instance_path_lookup()
        if side not in (None, 1, -1):
            raise ValueError(f"mate_tangent side must be 1, -1 or None, got {side!r}")
        mate = TangentMate(
            faceA=_resolve_face(face_a, self._scenes_dir, lookup),
            faceB=_resolve_face(face_b, self._scenes_dir, lookup),
            side=side,
        )
        self._doc.mates.append(mate)
        return mate.id

    # ─── Edge / vertex mates (foundation) ────────────────────────────────
    #
    # These mate variants serialize cleanly and round-trip through vCAD's
    # loader, but the SOLVER side (OndselSolver bridge + assembly-mode
    # edge/vertex picking) is still TODO — see
    # docs/PROJECT_ATLAS.md → "EdgeRef / VertexRef в mate'ах".
    # Authoring + .asm.json round-trip work today; geometric enforcement
    # at solve time lands in a follow-up.

    def mate_edge_coincident(self, edge_a: EdgeLike, edge_b: EdgeLike) -> str:
        """Edge-on-edge mate: two edges aligned end-to-end (collinear,
        sharing direction). Maps to Ondsel's line-on-line joint."""
        lookup = self._instance_path_lookup()
        mate = EdgeCoincidentMate(
            edgeA=_resolve_edge(edge_a, self._scenes_dir, lookup),
            edgeB=_resolve_edge(edge_b, self._scenes_dir, lookup),
        )
        self._doc.mates.append(mate)
        return mate.id

    def mate_point_coincident(
        self, vertex_a: VertexLike, vertex_b: VertexLike,
    ) -> str:
        """Two vertices snapped to the same world point. Maps to Ondsel's
        point-on-point joint."""
        lookup = self._instance_path_lookup()
        mate = PointCoincidentMate(
            pointA=_resolve_vertex(vertex_a, lookup),
            pointB=_resolve_vertex(vertex_b, lookup),
        )
        self._doc.mates.append(mate)
        return mate.id

    def mate_point_on_edge(self, vertex: VertexLike, edge: EdgeLike) -> str:
        """Vertex constrained to lie anywhere along an edge (1 DOF left:
        slide-along). Maps to Ondsel's point-on-line joint."""
        lookup = self._instance_path_lookup()
        mate = PointOnEdgeMate(
            point=_resolve_vertex(vertex, lookup),
            edge=_resolve_edge(edge, self._scenes_dir, lookup),
        )
        self._doc.mates.append(mate)
        return mate.id

    # ─── Motors (mechanism drives) ─────────────────────────────────────────

    def motor(
        self,
        mate_id: str,
        *,
        rev_per_sec: float | None = None,
        angle: str | None = None,
        mm_per_sec: float | None = None,
        distance: str | None = None,
        oscillate_deg: float | None = None,
        oscillate_mm: float | None = None,
        freq_hz: float = 1.0,
        phase_deg: float = 0.0,
        mover: PartInstance | str | None = None,
    ) -> str:
        """Drive a joint with a motor (rotational or linear).

        A motor says which side MOVES (``mover``) and which is the frame of
        reference. Pass exactly one of:
          * ``rev_per_sec`` — constant angular velocity (rotational), or
          * ``angle`` — SymbolicParser RADIANS as f(``time``), e.g.
            ``"2*pi*time"`` (= 1 rev/s) or ``"sin(time)"``; or
          * ``mm_per_sec`` — constant linear velocity (linear), or
          * ``distance`` — SymbolicParser mm as f(``time``), e.g. ``"10*time"``; or
          * ``oscillate_deg`` — periodic angle ±A° = A·sin(2π·freq·t) (rotational
            oscillation); or
          * ``oscillate_mm`` — periodic slide ±A mm (linear oscillation).

        ``freq_hz`` (default 1) and ``phase_deg`` (default 0) modify the
        oscillation. Rotational motors drive a concentric/revolute joint, linear
        motors a prismatic (slider) joint. ``mover`` defaults to the joint's
        non-fixed side; if neither side is fixed you must pass it explicitly.
        Returns the drive id.
        """
        provided = [rev_per_sec, angle, mm_per_sec, distance, oscillate_deg, oscillate_mm]
        if sum(p is not None for p in provided) != 1:
            raise ValueError(
                "motor(): pass exactly one of rev_per_sec=, angle=, mm_per_sec=, "
                "distance=, oscillate_deg= or oscillate_mm="
            )
        # Oscillation sugar → a `function` drive: A·sin(2π·freq·t + phase).
        if oscillate_deg is not None:
            angle = _sine_expr(math.radians(oscillate_deg), freq_hz, phase_deg)
        elif oscillate_mm is not None:
            distance = _sine_expr(oscillate_mm, freq_hz, phase_deg)
        is_linear = mm_per_sec is not None or distance is not None

        mate = next((m for m in self._doc.mates if m.id == mate_id), None)
        if mate is None:
            raise ValueError(f"motor(): no mate with id {mate_id!r}")
        if is_linear:
            if mate.type != "prismatic":
                raise ValueError(
                    f"motor(): mate {mate_id!r} is {mate.type!r}; "
                    "a linear motor needs a prismatic (slider) joint"
                )
        elif mate.type not in ("concentric", "revolute"):
            raise ValueError(
                f"motor(): mate {mate_id!r} is {mate.type!r}; "
                "a rotational motor needs a concentric/revolute joint"
            )
        a_id, b_id = mate.faceA.instanceId, mate.faceB.instanceId
        fixed = {d.id: bool(d.fixed) for d in self._doc.instances}
        if mover is not None:
            mover_id = mover.id if isinstance(mover, PartInstance) else mover
            if mover_id not in (a_id, b_id):
                raise ValueError("motor(): mover= must be one of the joint's two instances")
            base_id = b_id if mover_id == a_id else a_id
        else:
            a_fixed, b_fixed = fixed.get(a_id, False), fixed.get(b_id, False)
            if a_fixed and not b_fixed:
                mover_id, base_id = b_id, a_id
            elif b_fixed and not a_fixed:
                mover_id, base_id = a_id, b_id
            else:
                raise ValueError(
                    "motor(): neither joint side is fixed — pass mover= to say which instance turns"
                )
        drive: RotationalDrive | TranslationalDrive
        if is_linear:
            lin_motion = (
                {"type": "speed", "mmPerSec": float(mm_per_sec)}
                if mm_per_sec is not None
                else {"type": "function", "distance": str(distance)}
            )
            drive = TranslationalDrive(
                mateId=mate_id,
                moverInstanceId=mover_id,
                baseInstanceId=base_id,
                motion=lin_motion,
            )
        else:
            rot_motion = (
                {"type": "speed", "revPerSec": float(rev_per_sec)}
                if rev_per_sec is not None
                else {"type": "function", "angle": str(angle)}
            )
            drive = RotationalDrive(
                mateId=mate_id,
                moverInstanceId=mover_id,
                baseInstanceId=base_id,
                motion=rot_motion,
            )
        self._doc.drives.append(drive)
        return drive.id

    # ─── (De)serialization ────────────────────────────────────────────────

    def to_dict(self) -> dict:
        d = self._doc.model_dump(mode="json", by_alias=True, exclude_none=True)
        # Keep motor-free assemblies byte-identical to before this feature.
        if not d.get("drives"):
            d.pop("drives", None)
        return d

    def to_json(self, *, indent: int | None = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(self.to_json() + "\n", encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "Assembly":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_dict(raw)

    @classmethod
    def from_dict(cls, raw: dict) -> "Assembly":
        if not isinstance(raw, dict) or raw.get("kind") != "assembly":
            raise ValueError("Not an assembly document (missing `kind: assembly`).")
        assembly = cls()
        assembly._doc = AssemblyDoc.model_validate(raw)
        return assembly


# ─── Scene builder ──────────────────────────────────────────────────────────


class Scene:
    """Top-level document. Use `.add_body()` then drive the returned Body."""

    def __init__(self) -> None:
        self._doc = SceneDoc()

    def add_body(self, name: str = "Body") -> Body:
        body_doc = BodyDoc(name=name)
        self._doc.bodies.append(body_doc)
        return Body(body_doc)

    @property
    def bodies(self) -> list[Body]:
        return [Body(b) for b in self._doc.bodies]

    def boolean(
        self,
        operation: Literal["union", "difference", "intersection"],
        a: Body | str,
        b: Body | str,
        name: str | None = None,
    ) -> Body:
        """Build a CSG boolean of two bodies. Adds a new body to the scene
        carrying a Feature{type:'boolean'} that references the source body
        ids; vCAD computes the actual mesh on load.

        Accepts Body instances or raw body ids.
        """
        a_id = a.id if isinstance(a, Body) else a
        b_id = b.id if isinstance(b, Body) else b
        body_doc = BodyDoc(name=name or operation.capitalize())
        body_doc.features.append(
            Feature(
                type="boolean",
                boolean_operation=operation,
                boolean_body_ids=[a_id, b_id],
            )
        )
        self._doc.bodies.append(body_doc)
        return Body(body_doc)

    # ─── (De)serialization ─────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return self._doc.model_dump(mode="json", by_alias=True, exclude_none=True)

    def to_json(self, *, indent: int | None = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(self.to_json() + "\n", encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "Scene":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_dict(raw)

    @classmethod
    def from_dict(cls, raw: dict) -> "Scene":
        # Accept a few historical wrappers: {kind:'part', scene:{...}} or the
        # bare scene description. Anything else falls through unchanged.
        if isinstance(raw, dict) and raw.get("kind") == "part" and "scene" in raw:
            raw = raw["scene"]
        scene = cls()
        scene._doc = SceneDoc.model_validate(raw)
        return scene
