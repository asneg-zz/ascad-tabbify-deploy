"""ID generation that mirrors `src/utils/generateId.ts` (UUIDv4)."""

from __future__ import annotations

import uuid


def generate_id() -> str:
    """Lowercase UUIDv4 with hyphens — matches vCAD TS-side ids."""
    return str(uuid.uuid4())
