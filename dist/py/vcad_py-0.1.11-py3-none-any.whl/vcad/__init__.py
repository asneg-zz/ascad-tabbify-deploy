"""vcad-py — Python authoring library for vCAD scene/sketch JSON documents.

Phase 1: sketch primitives + minimal scene wrapping (body + sketch feature).
Extrude/cut/revolve/fillet/chamfer/boolean and assembly support land in later
phases (see wasm_vCAD/docs/PY_LIBRARY_PLAN.md).
"""

from vcad.builders import Assembly, Body, PartInstance, Scene, Sketch
from vcad.gears import GearParams, add_gear_sketch, gear_outline, one_tooth_outline
from vcad.models import (
    ArcElement,
    CircleElement,
    DimensionElement,
    EllipseElement,
    LineElement,
    NamedEntity,
    NamedEntityAnchor,
    Plane,
    Point2D,
    PointElement,
    PolygonElement,
    PolylineElement,
    RectangleElement,
    SlotElement,
    SplineElement,
    TextElement,
)
from vcad.text import text_to_contours

__all__ = [
    "Scene",
    "Body",
    "Sketch",
    "Plane",
    "Point2D",
    "PointElement",
    "LineElement",
    "CircleElement",
    "ArcElement",
    "RectangleElement",
    "PolylineElement",
    "SplineElement",
    "DimensionElement",
    "PolygonElement",
    "EllipseElement",
    "SlotElement",
    "TextElement",
    "text_to_contours",
    "GearParams",
    "one_tooth_outline",
    "gear_outline",
    "add_gear_sketch",
    "Assembly",
    "PartInstance",
    "NamedEntity",
    "NamedEntityAnchor",
]
