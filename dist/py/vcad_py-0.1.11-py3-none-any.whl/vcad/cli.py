"""vcad-py command-line interface.

Subcommands:
    validate  — parse a scene/assembly/part JSON and report schema errors
    diff      — structural diff between two JSON documents, ignoring
                feature IDs and cached_mesh fields
    upload    — POST a JSON document to a dev-server URL
                (multipart/form-data with field ``file``)

Run ``vcad-py --help`` for the full surface.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from . import models


# ─── Loaders ───────────────────────────────────────────────────────────────

def _read_json(path: Path) -> Any:
    """Read JSON from disk. Returns the raw parsed structure (dict / list).
    Caller is expected to catch JSONDecodeError + OSError and emit a
    user-facing message."""
    return json.loads(path.read_text(encoding="utf-8"))


def _classify(raw: Any) -> str:
    """Best-effort guess at which top-level model fits the document. We
    look at field shape rather than file name so a renamed ``.json`` still
    works.

    Part files wrap a scene: ``{"kind": "part", "scene": {...}}``. We
    treat them as scenes for validation by unwrapping ``scene`` before
    handing to the model.
    """
    if not isinstance(raw, dict):
        return "unknown"
    if raw.get("kind") == "part" and isinstance(raw.get("scene"), dict):
        return "part"
    if "bodies" in raw:
        return "scene"
    if "instances" in raw and "mates" in raw:
        return "assembly"
    return "unknown"


# ─── Validate ──────────────────────────────────────────────────────────────

def cmd_validate(args: argparse.Namespace) -> int:
    path = Path(args.file)
    try:
        raw = _read_json(path)
    except (json.JSONDecodeError, OSError) as e:
        print(f"error: cannot read {path}: {e}", file=sys.stderr)
        return 2

    kind = _classify(raw)
    if kind == "unknown":
        print(
            f"error: {path}: doesn't look like a scene / assembly / part document",
            file=sys.stderr,
        )
        return 2

    # Part files wrap a SceneDoc; everything else is parsed directly.
    target_raw = raw["scene"] if kind == "part" else raw
    model_cls = {
        "scene":    models.SceneDoc,
        "part":     models.SceneDoc,
        "assembly": models.AssemblyDoc,
    }.get(kind)
    if model_cls is None:
        print(f"error: no validator for kind '{kind}'", file=sys.stderr)
        return 2

    try:
        model_cls.model_validate(target_raw)
    except Exception as e:  # pydantic.ValidationError + anything else
        print(f"invalid ({kind}): {e}", file=sys.stderr)
        return 1

    print(f"ok ({kind}): {path}")
    return 0


# ─── Diff ──────────────────────────────────────────────────────────────────

# Fields we strip before comparing — they carry per-load state, not
# structural meaning. Same list the decompiler round-trip suite uses.
_VOLATILE_KEYS = {
    "id",                          # feature/body/element IDs are random
    "cached_mesh_vertices",
    "cached_mesh_indices",
    "cached_mesh_normals",
    "cached_mesh_edges",
    "cached_mesh_face_groups",
}


def _strip_volatile(node: Any) -> Any:
    """Recursively drop volatile keys so the diff focuses on structural
    + geometric differences. Returns a new structure; input is not
    mutated."""
    if isinstance(node, dict):
        return {
            k: _strip_volatile(v)
            for k, v in node.items()
            if k not in _VOLATILE_KEYS
        }
    if isinstance(node, list):
        return [_strip_volatile(item) for item in node]
    return node


def _walk_diff(a: Any, b: Any, path: str, out: list[str]) -> None:
    """Append human-readable diff lines for the (a, b) pair at `path`. The
    output is intentionally simple — one line per leaf mismatch + one
    line per structural divergence — so it pipes nicely into grep."""
    if type(a) is not type(b):
        out.append(f"{path}: type {type(a).__name__} vs {type(b).__name__}")
        return
    if isinstance(a, dict):
        keys = sorted(set(a) | set(b))
        for k in keys:
            sub_path = f"{path}.{k}" if path else k
            if k not in a:
                out.append(f"+ {sub_path}: {b[k]!r}")
            elif k not in b:
                out.append(f"- {sub_path}: {a[k]!r}")
            else:
                _walk_diff(a[k], b[k], sub_path, out)
        return
    if isinstance(a, list):
        if len(a) != len(b):
            out.append(f"{path}: length {len(a)} vs {len(b)}")
        for i in range(min(len(a), len(b))):
            _walk_diff(a[i], b[i], f"{path}[{i}]", out)
        return
    if a != b:
        out.append(f"{path}: {a!r} → {b!r}")


def cmd_diff(args: argparse.Namespace) -> int:
    path_a, path_b = Path(args.a), Path(args.b)
    try:
        raw_a = _strip_volatile(_read_json(path_a))
        raw_b = _strip_volatile(_read_json(path_b))
    except (json.JSONDecodeError, OSError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2

    diffs: list[str] = []
    _walk_diff(raw_a, raw_b, "", diffs)
    if not diffs:
        print(f"identical (modulo IDs + cached meshes): {path_a} ≡ {path_b}")
        return 0

    for line in diffs:
        print(line)
    return 1


# ─── Upload ────────────────────────────────────────────────────────────────

def cmd_upload(args: argparse.Namespace) -> int:
    """POST the file to `--host` as multipart/form-data. Uses the stdlib
    so we don't add a runtime dependency on requests/httpx — the CLI
    stays usable in environments where pip-installing extras is
    awkward."""
    path = Path(args.file)
    if not path.exists():
        print(f"error: {path} does not exist", file=sys.stderr)
        return 2

    try:
        payload = path.read_bytes()
    except OSError as e:
        print(f"error: cannot read {path}: {e}", file=sys.stderr)
        return 2

    boundary = "----vcadpyboundary7e3b9c4a"
    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="file"; filename="{path.name}"\r\n'
        "Content-Type: application/json\r\n\r\n"
    ).encode("utf-8") + payload + f"\r\n--{boundary}--\r\n".encode("utf-8")

    import urllib.error
    import urllib.request
    req = urllib.request.Request(
        args.host,
        data=body,
        method="POST",
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            status = resp.status
            text = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        print(f"error: HTTP {e.code} {e.reason}", file=sys.stderr)
        return 1
    except urllib.error.URLError as e:
        print(f"error: {e.reason}", file=sys.stderr)
        return 1

    print(f"ok: HTTP {status}")
    if text:
        print(text)
    return 0


# ─── Entry point ───────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="vcad-py", description=__doc__)
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_val = sub.add_parser("validate", help="check a JSON document against the vcad schema")
    p_val.add_argument("file", help="path to scene / assembly / part JSON")
    p_val.set_defaults(func=cmd_validate)

    p_diff = sub.add_parser("diff", help="structural diff between two JSON documents")
    p_diff.add_argument("a", help="first JSON file")
    p_diff.add_argument("b", help="second JSON file")
    p_diff.set_defaults(func=cmd_diff)

    p_up = sub.add_parser("upload", help="POST a JSON document to a dev-server URL")
    p_up.add_argument("file", help="path to JSON")
    p_up.add_argument("--host", required=True, help="upload URL, e.g. http://localhost:5176/api/scene")
    p_up.set_defaults(func=cmd_upload)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    sys.exit(main())
