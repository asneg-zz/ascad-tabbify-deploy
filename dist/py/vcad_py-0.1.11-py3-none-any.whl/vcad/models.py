"""Pydantic models mirroring the on-disk vCAD scene JSON.

Authoritative TS definitions live in `wasm_vCAD/src/types/scene.ts`. Wire
format produced by `wasm_vCAD/src/utils/sceneSerializer.ts` is the contract
we round-trip against.

Phase 1 covers sketch primitives + the minimal Scene wrapper (Body with a
single sketch Feature). Extrude/cut/revolve/fillet/chamfer/boolean live in
later phases; for now they pass through as opaque dicts so existing scenes
still load.
"""

from __future__ import annotations

from enum import Enum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from vcad.ids import generate_id


# ─── Geometric primitives ───────────────────────────────────────────────────


class Point2D(BaseModel):
    """2D point in sketch-plane coordinates."""

    model_config = ConfigDict(extra="forbid")

    x: float
    y: float


class Plane(str, Enum):
    """Standard sketch planes. Use `Plane.XY` etc."""

    XY = "XY"
    XZ = "XZ"
    YZ = "YZ"
    CUSTOM = "CUSTOM"


class FaceCoordSystem(BaseModel):
    """Full coordinate system for sketches on non-axis-aligned faces."""

    model_config = ConfigDict(extra="forbid")

    origin: tuple[float, float, float]
    normal: tuple[float, float, float]
    uAxis: tuple[float, float, float]
    vAxis: tuple[float, float, float]


class Transform(BaseModel):
    """Affine transform written on sketch/primitive features.

    Identity by default. vCAD emits this on primitives (position + scale
    matter) and on sketch features (kept at identity).
    """

    model_config = ConfigDict(extra="forbid")

    position: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation: tuple[float, float, float] = (0.0, 0.0, 0.0)
    scale: tuple[float, float, float] = (1.0, 1.0, 1.0)


class Primitive(BaseModel):
    """Built-in solid primitive embedded in a Feature{type:'primitive'}.

    Field semantics depend on `type`:
      cube     → width × height × depth (defaults all 1)
      cylinder → radius (0.5) × height (1)
      sphere   → radius (0.5)
      cone     → radius (0.5) × height (1)

    Unused fields are omitted on serialise.
    """

    model_config = ConfigDict(extra="forbid")

    type: Literal["cube", "cylinder", "sphere", "cone"]
    width: float | None = None
    height: float | None = None
    depth: float | None = None
    radius: float | None = None


class EdgeVertices(BaseModel):
    """One picked edge as its two endpoints. Used by Fillet/Chamfer 3D."""

    model_config = ConfigDict(extra="forbid")

    start: tuple[float, float, float]
    end: tuple[float, float, float]


class Fillet3DParams(BaseModel):
    model_config = ConfigDict(extra="forbid")

    edge_vertices: list[EdgeVertices]
    radius: float
    segments: int = 8
    # Selector form: round ALL edges of the matched face(s). Each face is a
    # (point-on-face, outward-normal) anchor — one selector covers a whole loop.
    face_selectors: list[FaceAnchor] = []


class Chamfer3DParams(BaseModel):
    model_config = ConfigDict(extra="forbid")

    edge_vertices: list[EdgeVertices]
    distance1: float
    distance2: float
    ref_normal: tuple[float, float, float] | None = None
    # See Fillet3DParams.face_selectors — chamfer ALL edges of the matched face(s).
    face_selectors: list[FaceAnchor] = []


class FaceAnchor(BaseModel):
    """One face identified by its centroid + outward normal. Used by
    the shell feature to mark faces to remove from the hollowed solid.
    """

    model_config = ConfigDict(extra="forbid")

    point: tuple[float, float, float]
    normal: tuple[float, float, float]


class ShellParams(BaseModel):
    """Hollow a solid to ``thickness``; optionally pierce the listed
    faces (open shell). Empty ``faces_to_remove`` makes a closed
    shell — same outer shape, hollow interior."""

    model_config = ConfigDict(extra="forbid")

    thickness: float
    faces_to_remove: list[FaceAnchor] = []


class MirrorParams(BaseModel):
    """Reflect the current solid across a plane.

    ``merge=True`` (default) fuses the mirrored copy with the original
    — typical "design one half, get the symmetric whole".
    ``merge=False`` just reflects, replacing the original.

    For axis-aligned planes set ``plane`` to ``'XY'`` / ``'XZ'`` /
    ``'YZ'`` and leave origin/normal unset. For an arbitrary plane
    use ``'CUSTOM'`` + ``origin`` + ``normal``.
    """

    model_config = ConfigDict(extra="forbid")

    plane: Literal["XY", "XZ", "YZ", "CUSTOM"]
    origin: tuple[float, float, float] | None = None
    normal: tuple[float, float, float] | None = None
    merge: bool = True


class ScaleBodyParams(BaseModel):
    """Resize the current solid by a factor along each axis.

    Only *uniform* scaling (``x == y == z``) is honoured by vCAD today —
    replicad exposes a single-factor gp_Trsf scale and the current
    opencascade.js build lacks the non-uniform ``BRepBuilderAPI_GTransform``.
    Per-axis fields are kept for a future upgrade. ``center`` is the fixed
    point of the scaling; when omitted the body's bounding-box centre is
    used so the part scales in place.
    """

    model_config = ConfigDict(extra="forbid")

    x: float
    y: float
    z: float
    center: tuple[float, float, float] | None = None


class LinearPattern3DParams(BaseModel):
    """Repeat the current solid along a direction.

    ``count`` includes the original at index 0 — count=5 makes 5
    copies total (4 translated). ``direction`` is normalised
    internally; ``spacing`` is the centre-to-centre distance in mm
    between adjacent copies. ``merge=True`` (default) fuses the
    copies into one solid.
    """

    model_config = ConfigDict(extra="forbid")

    direction: tuple[float, float, float]
    count: int
    spacing: float
    merge: bool = True


class CircularPattern3DParams(BaseModel):
    """Repeat the current solid around an axis.

    Axis = ``axis_point`` (any point on it) + ``axis_direction``
    (need not be unit-length). ``count`` includes the original at
    index 0; copies sit at ``step_angle_deg * i`` for i = 1..count-1.

    For a full-circle pattern of N items: ``count=N``,
    ``step_angle_deg = 360 / N``. ``merge=True`` (default) fuses the
    copies into one solid.
    """

    model_config = ConfigDict(extra="forbid")

    axis_point: tuple[float, float, float]
    axis_direction: tuple[float, float, float]
    count: int
    step_angle_deg: float
    merge: bool = True


class LoftParams(BaseModel):
    """Interpolate a solid between ≥ 2 cross-section sketches.

    ``loft_sketch_ids`` lists the cross-section sketch features in
    order (start → end). Each sketch lives on its own plane (commonly
    parallel, at varying Z) and provides one closed contour.

    ``ruled=True`` produces a piecewise-linear surface between adjacent
    sections; default ``False`` is a smooth C2 interpolation.
    """

    model_config = ConfigDict(extra="forbid")

    loft_sketch_ids: list[str]
    ruled: bool = False


class StepImportParams(BaseModel):
    """Import an external CAD model from a STEP file.

    ``content_b64`` holds the STEP file content as a base64 string —
    the scene JSON stays self-contained at the cost of size (fine for
    small parts, painful for large assemblies). ``source_path``
    records the original filename for debugging / re-export; the
    engine ignores it.
    """

    model_config = ConfigDict(extra="forbid")

    content_b64: str
    source_path: str | None = None


# ─── Sketch elements ────────────────────────────────────────────────────────
#
# Each element is one variant of a discriminated union keyed on `type`.
# Defaults match what sceneSerializer.ts emits — anything optional is opt-in.


class _ElementBase(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str = Field(default_factory=generate_id)


class PointElement(_ElementBase):
    type: Literal["point"] = "point"
    position: Point2D


class LineElement(_ElementBase):
    type: Literal["line"] = "line"
    start: Point2D
    end: Point2D


class CircleElement(_ElementBase):
    type: Literal["circle"] = "circle"
    center: Point2D
    radius: float


class ArcElement(_ElementBase):
    type: Literal["arc"] = "arc"
    center: Point2D
    radius: float
    start_angle: float
    end_angle: float


class RectangleElement(_ElementBase):
    type: Literal["rectangle"] = "rectangle"
    corner: Point2D
    width: float
    height: float


class PolylineElement(_ElementBase):
    type: Literal["polyline"] = "polyline"
    points: list[Point2D]


class SplineElement(_ElementBase):
    type: Literal["spline"] = "spline"
    points: list[Point2D]


class PolygonElement(_ElementBase):
    type: Literal["polygon"] = "polygon"
    center: Point2D
    radius: float
    sides: int


class EllipseElement(_ElementBase):
    type: Literal["ellipse"] = "ellipse"
    center: Point2D
    radiusX: float
    radiusY: float
    rotation: float = 0.0


class SlotElement(_ElementBase):
    type: Literal["slot"] = "slot"
    start: Point2D
    end: Point2D
    radius: float


class TextElement(_ElementBase):
    type: Literal["text"] = "text"
    position: Point2D
    text: str
    font_size: float
    # Precomputed closed glyph contours, relative to `position` (+Y up). The
    # viewer and extruder read these directly — no font needed at render time.
    text_contours: list[list[Point2D]] = Field(default_factory=list)


class DimensionElement(_ElementBase):
    type: Literal["dimension"] = "dimension"
    from_: Point2D = Field(alias="from")
    to: Point2D
    value: float
    parameter_name: str | None = None
    dimension_line_pos: Point2D | None = None
    target_element: int | None = None
    dimension_type: Literal["linear", "radius", "diameter"] = "linear"

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


SketchElement = Annotated[
    PointElement
    | LineElement
    | CircleElement
    | ArcElement
    | RectangleElement
    | PolylineElement
    | SplineElement
    | PolygonElement
    | EllipseElement
    | SlotElement
    | TextElement
    | DimensionElement,
    Field(discriminator="type"),
]


# ─── Constraints ────────────────────────────────────────────────────────────


class PointRef(BaseModel):
    """Reference to a specific point on an element. `element_index` is the
    sketch-elements-array index (NOT the id — the builder resolves ids).
    `point_index` is 0/1/2 etc., semantics depend on the element type:
    line → 0=start, 1=end; arc → 0=center, 1=start, 2=end;
    circle/polygon/ellipse → 0=center; polyline/spline → vertex index.
    """

    model_config = ConfigDict(extra="forbid")

    element_index: int
    point_index: int


class _ConstraintBase(BaseModel):
    model_config = ConfigDict(extra="forbid")

    # The editor stamps every constraint with a stable id (used to key
    # dimension overlays etc.). We preserve it on round-trip but never invent
    # one for Python-authored constraints — `id=None` is dropped by
    # `exclude_none` on dump, mirroring DimensionElement's optional fields.
    id: str | None = None


class HorizontalConstraint(_ConstraintBase):
    type: Literal["horizontal"] = "horizontal"
    element: int


class VerticalConstraint(_ConstraintBase):
    type: Literal["vertical"] = "vertical"
    element: int


class FixedConstraint(_ConstraintBase):
    type: Literal["fixed"] = "fixed"
    element: int


class ParallelConstraint(_ConstraintBase):
    type: Literal["parallel"] = "parallel"
    element1: int
    element2: int


class PerpendicularConstraint(_ConstraintBase):
    type: Literal["perpendicular"] = "perpendicular"
    element1: int
    element2: int


class EqualConstraint(_ConstraintBase):
    type: Literal["equal"] = "equal"
    element1: int
    element2: int


class TangentConstraint(_ConstraintBase):
    type: Literal["tangent"] = "tangent"
    element1: int
    element2: int


class ConcentricConstraint(_ConstraintBase):
    type: Literal["concentric"] = "concentric"
    element1: int
    element2: int


class SymmetricConstraint(_ConstraintBase):
    type: Literal["symmetric"] = "symmetric"
    element1: int
    element2: int
    axis: int


class CoincidentConstraint(_ConstraintBase):
    type: Literal["coincident"] = "coincident"
    point1: PointRef
    point2: PointRef


class DistanceConstraint(_ConstraintBase):
    type: Literal["distance"] = "distance"
    point1: PointRef
    point2: PointRef
    value: float


class AngleConstraint(_ConstraintBase):
    type: Literal["angle"] = "angle"
    element1: int
    element2: int
    value: float


class RadiusConstraint(_ConstraintBase):
    type: Literal["radius"] = "radius"
    element: int
    value: float


class PointOnLineConstraint(_ConstraintBase):
    type: Literal["point_on_line"] = "point_on_line"
    point: PointRef
    line: int


class PointOnCircleConstraint(_ConstraintBase):
    type: Literal["point_on_circle"] = "point_on_circle"
    point: PointRef
    circle: int


class MidpointConstraint(_ConstraintBase):
    type: Literal["midpoint"] = "midpoint"
    line1: int
    line2: int


SketchConstraint = Annotated[
    HorizontalConstraint
    | VerticalConstraint
    | FixedConstraint
    | ParallelConstraint
    | PerpendicularConstraint
    | EqualConstraint
    | TangentConstraint
    | ConcentricConstraint
    | SymmetricConstraint
    | CoincidentConstraint
    | DistanceConstraint
    | AngleConstraint
    | RadiusConstraint
    | PointOnLineConstraint
    | PointOnCircleConstraint
    | MidpointConstraint,
    Field(discriminator="type"),
]


# ─── Sketch ─────────────────────────────────────────────────────────────────


class SketchDoc(BaseModel):
    """The `sketch` field of a Feature{type:'sketch'}."""

    model_config = ConfigDict(extra="forbid")

    plane: Plane = Plane.XY
    offset: float = 0.0
    elements: list[SketchElement] = Field(default_factory=list)
    face_normal: tuple[float, float, float] | None = None
    face_coord_system: FaceCoordSystem | None = None
    construction_ids: list[str] | None = None
    revolve_axis: int | None = None
    symmetry_axis: int | None = None
    # Optional + None default so empty sketches don't emit `constraints: []`
    # — matches what wasm_vCAD writes when the user hasn't added any.
    constraints: list[SketchConstraint] | None = None


# ─── Body / Feature / Scene ─────────────────────────────────────────────────
#
# Non-sketch features (extrude/cut/revolve/etc.) are kept as opaque dicts in
# Phase 1. They serialize unchanged from input and the Python builder API
# emits sketches only.


class Feature(BaseModel):
    """One feature in a body.

    Single model rather than a typed union: vCAD's on-disk format keeps
    feature parameters flat on the feature object (e.g. extrude has
    `height`/`height_backward`/`draft_angle`/`cut` directly, not nested
    under `extrude_params`). Builder methods set only the fields that
    matter for each type; `extra='allow'` keeps any extra fields from
    existing scenes round-trippable.
    """

    model_config = ConfigDict(extra="allow")

    id: str = Field(default_factory=generate_id)
    type: str
    sketch: SketchDoc | None = None
    transform: Transform | None = None
    primitive: Primitive | None = None


class NamedEntityAnchor(BaseModel):
    """Stable 3D anchor for a named face/edge — mirror of TypeScript
    `NamedEntityAnchor` in wasm_vCAD/src/types/scene.ts. The anchor lets
    vCAD re-locate the entity after OCCT regenerates the mesh.
    """

    model_config = ConfigDict(extra="forbid")

    point: tuple[float, float, float]
    normal: tuple[float, float, float]
    endpoint: tuple[float, float, float] | None = None


class NamedEntity(BaseModel):
    """User-given label attached to a face or edge of a body. Persists
    across feature edits via the geometric anchor; `id` is what mates
    reference (Phase D); `name` is the human-facing label.
    """

    model_config = ConfigDict(extra="forbid")

    id: str = Field(default_factory=generate_id)
    name: str
    kind: Literal["face", "edge"]
    color: str | None = None
    anchor: NamedEntityAnchor


class BodyDoc(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str = Field(default_factory=generate_id)
    name: str = "Body"
    visible: bool = True
    features: list[Feature] = Field(default_factory=list)
    named_entities: list[NamedEntity] | None = None
    # Per-body display colour (hex "#rrggbb"). None → the app's default colour.
    color: str | None = None
    # Material id (mass/dynamics) → density; None = app default material.
    material: str | None = None
    # Explicit density override (kg/m³); wins over `material` when set.
    density: float | None = None
    # `persist` defaults to true and is only written to disk when false
    # (matches the wasm_vCAD serializer). `None` here means "use the
    # default" — keep the round-trip diff-free for files that omit it.
    persist: bool | None = None


class SceneDoc(BaseModel):
    """Top-level on-disk scene format (matches SceneDescriptionV2).

    `version` is the schema version; vCAD writes `2`. `body_operations` is
    legacy — kept as `list` for forward-compat; vCAD also emits `operations`
    in some paths. We accept both.
    """

    model_config = ConfigDict(extra="allow")

    version: int = 2
    bodies: list[BodyDoc] = Field(default_factory=list)
    body_operations: list[dict[str, Any]] = Field(default_factory=list)


# ─── Assembly documents ─────────────────────────────────────────────────────
#
# Mirror wasm_vCAD/src/types/document.ts. Assemblies live in
# `.asm.json` files and reference parts (`.part.json`/`.json`) by path —
# no embedded geometry. vCAD's OCCT replay rebuilds the mesh on load.


class Transform3D(BaseModel):
    """Rigid 3D transform written on every PartInstance.

    Identity by default. `rotation` is a quaternion `(x, y, z, w)` —
    same order vCAD's assembly solver consumes.
    """

    model_config = ConfigDict(extra="forbid")

    translation: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 1.0)


class PartRef(BaseModel):
    model_config = ConfigDict(extra="forbid")

    path: str


class PartInstanceDoc(BaseModel):
    """One placed copy of a part inside an assembly. The assembly solver
    moves non-fixed instances; `fixed=True` anchors one in place."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(default_factory=generate_id)
    partRef: PartRef
    transform: Transform3D = Field(default_factory=Transform3D)
    fixed: bool | None = None
    hidden: bool | None = None
    name: str | None = None


class FaceGeomDoc(BaseModel):
    """Part-local face geometry — centroid + outward normal in the part's own
    coordinate frame. Lets vCAD re-resolve a face by nearest centroid/normal at
    solve time instead of by OCCT hashCode (which is unstable across
    re-tessellation). The `axis` of a cylindrical face is re-derived from the
    matched live face, so it isn't serialised here."""

    model_config = ConfigDict(extra="forbid")

    centroid: tuple[float, float, float]
    normal: tuple[float, float, float]


class FaceRefDoc(BaseModel):
    model_config = ConfigDict(extra="forbid")

    instanceId: str
    # bodyId disambiguates which body inside the part owns the face.
    # vCAD requires it to look up named-face → faceId at mate-resolve
    # time (the named-face map is keyed by (instanceId, bodyId)).
    bodyId: str | None = None
    faceId: int
    # Optional NamedEntity reference — when set, vCAD prefers this over
    # the brittle hashCode at mate-resolve time. `namedEntityId` is the
    # uuid persisted on the source part's body; `namedEntityName` is a
    # frozen copy for display fallback.
    namedEntityId: str | None = None
    namedEntityName: str | None = None
    # Optional geometric selector (see PartInstance.face_at). When set, vCAD
    # resolves the face by geometry — stable across re-tessellation, so a
    # decompiled script round-trips without losing unnamed-face mates.
    geom: FaceGeomDoc | None = None


class EdgeRefDoc(BaseModel):
    """Reference to one edge of a part instance — sibling of FaceRefDoc.

    bodyId disambiguates which body inside the part owns the edge.
    edgeId is OCCT's hashCode snapshot (unstable across re-tessellation);
    prefer ``namedEntity*`` binding when the user labelled the edge.

    Runtime support in vCAD is partial: serialization works, but mate
    solving + edge picking in assembly-mode are TODO (see
    docs/PROJECT_ATLAS.md → "EdgeRef / VertexRef в mate'ах").
    """

    model_config = ConfigDict(extra="forbid")

    instanceId: str
    bodyId: str | None = None
    edgeId: int
    namedEntityId: str | None = None
    namedEntityName: str | None = None


class VertexRefDoc(BaseModel):
    """Reference to one vertex of a part instance."""

    model_config = ConfigDict(extra="forbid")

    instanceId: str
    bodyId: str | None = None
    vertexId: int
    namedEntityId: str | None = None
    namedEntityName: str | None = None


class _MateBase(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str = Field(default_factory=generate_id)


class FixMate(_MateBase):
    type: Literal["fix"] = "fix"
    instanceId: str


class CoincidentMate(_MateBase):
    type: Literal["coincident"] = "coincident"
    faceA: FaceRefDoc
    faceB: FaceRefDoc
    flip: bool | None = None


class DistanceMate(_MateBase):
    type: Literal["distance"] = "distance"
    faceA: FaceRefDoc
    faceB: FaceRefDoc
    value: float


class ConcentricMate(_MateBase):
    type: Literal["concentric"] = "concentric"
    faceA: FaceRefDoc
    faceB: FaceRefDoc


class RevoluteMate(_MateBase):
    """A true 1-DOF pin: two cylindrical faces with aligned axes AND a
    locked axial slide (only rotation stays free). Same fields as
    ConcentricMate; the solver builds an ASMTRevoluteJoint instead of a
    cylindrical one, so a motor drives it with no concentric→revolute
    promotion."""

    type: Literal["revolute"] = "revolute"
    faceA: FaceRefDoc
    faceB: FaceRefDoc


class PrismaticMate(_MateBase):
    """A true 1-DOF slider: two cylindrical faces with aligned axes AND a
    locked rotation (only the axial slide stays free) — the inverse of
    RevoluteMate. The solver builds an ASMTTranslationalJoint."""

    type: Literal["prismatic"] = "prismatic"
    faceA: FaceRefDoc
    faceB: FaceRefDoc


class TangentMate(_MateBase):
    """A cylindrical face resting on a planar face: the axis stays parallel
    to the plane at perpendicular distance = radius (the surface just
    touches). One face must be cylindrical, the other planar; order is
    irrelevant. Leaves slide-in-plane + roll/spin free — a rod on a table."""

    type: Literal["tangent"] = "tangent"
    faceA: FaceRefDoc
    faceB: FaceRefDoc
    #: Which side of the planar face the cylinder rests on: +1 along the face
    #: normal, -1 against it. None = auto (whichever side the axis is nearer).
    side: Literal[1, -1] | None = None


class EdgeCoincidentMate(_MateBase):
    """Two edges aligned end-to-end (collinear). Mirrors the TypeScript
    ``EdgeCoincidentMate`` — runtime path is TODO at the solver level."""

    type: Literal["edge_coincident"] = "edge_coincident"
    edgeA: EdgeRefDoc
    edgeB: EdgeRefDoc


class PointCoincidentMate(_MateBase):
    """Two vertices snapped to the same point."""

    type: Literal["point_coincident"] = "point_coincident"
    pointA: VertexRefDoc
    pointB: VertexRefDoc


class PointOnEdgeMate(_MateBase):
    """Vertex constrained to lie anywhere along an edge."""

    type: Literal["point_on_edge"] = "point_on_edge"
    point: VertexRefDoc
    edge: EdgeRefDoc


Mate = Annotated[
    FixMate
    | CoincidentMate
    | DistanceMate
    | ConcentricMate
    | RevoluteMate
    | PrismaticMate
    | TangentMate
    | EdgeCoincidentMate
    | PointCoincidentMate
    | PointOnEdgeMate,
    Field(discriminator="type"),
]


# ─── Drives (motors) ──────────────────────────────────────────────────
#
# A mate (e.g. concentric) is symmetric — a Drive adds direction: which
# instance turns (mover), which is the frame (base), and the motion profile.
# Kept separate from the mate so joints stay pure constraints.


class _SpeedMotion(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: Literal["speed"] = "speed"
    revPerSec: float


class _FunctionMotion(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: Literal["function"] = "function"
    # SymbolicParser angle in radians, as f(time), e.g. "2*pi*time".
    angle: str


Motion = Annotated[
    _SpeedMotion | _FunctionMotion,
    Field(discriminator="type"),
]


class _LinearSpeedMotion(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: Literal["speed"] = "speed"
    mmPerSec: float


class _LinearFunctionMotion(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: Literal["function"] = "function"
    # SymbolicParser distance in mm, as f(time), e.g. "10*time".
    distance: str


LinearMotion = Annotated[
    _LinearSpeedMotion | _LinearFunctionMotion,
    Field(discriminator="type"),
]


class RotationalDrive(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str = Field(default_factory=generate_id)
    kind: Literal["rotational"] = "rotational"
    mateId: str
    moverInstanceId: str
    baseInstanceId: str
    motion: Motion


class TranslationalDrive(BaseModel):
    """Linear motor on a prismatic mate: drives the axial slide. Mirror of
    RotationalDrive — `speed` is constant velocity (mm/s), `function` a
    SymbolicParser distance (mm) as f(time)."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(default_factory=generate_id)
    kind: Literal["translational"] = "translational"
    mateId: str
    moverInstanceId: str
    baseInstanceId: str
    motion: LinearMotion


Drive = Annotated[
    RotationalDrive | TranslationalDrive,
    Field(discriminator="kind"),
]


class AssemblyDoc(BaseModel):
    """`.asm.json` top-level payload. vCAD's loader keys on
    `kind == 'assembly'` to route to AssemblyMode."""

    model_config = ConfigDict(extra="forbid")

    kind: Literal["assembly"] = "assembly"
    name: str | None = None
    instances: list[PartInstanceDoc] = Field(default_factory=list)
    mates: list[Mate] = Field(default_factory=list)
    drives: list[Drive] = Field(default_factory=list)
