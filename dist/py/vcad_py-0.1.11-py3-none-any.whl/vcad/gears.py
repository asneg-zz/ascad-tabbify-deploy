"""Involute spur-gear primitives.

Builds GOST 13755-compatible spur-gear geometry directly into a vCAD
sketch. The package layer exposes:

  - ``GearParams``: dataclass with the ГОСТ diameters computed from
    module + teeth count.
  - ``one_tooth_outline()``: closed polyline of a single tooth with the
    axis along +X.
  - ``add_gear_sketch()``: convenience builder that adds the central
    disc + circular array of teeth to an existing ``Sketch``.

The recipe deliberately matches what a CAD modeller does by hand —
draw a disc at the root diameter, draw one tooth, circular-pattern it
around the centre — so an extruded sketch lands as a single fused
solid (OCCT's extrude/fuse path handles the multiple closed profiles).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from vcad.builders import Sketch


# ─── Math helpers ────────────────────────────────────────────────────────


def _involute_xy(rb: float, t: float) -> tuple[float, float]:
    """Standard involute unwound CCW from (rb, 0)."""
    return (
        rb * (math.cos(t) + t * math.sin(t)),
        rb * (math.sin(t) - t * math.cos(t)),
    )


def _involute_t_for_radius(rb: float, r: float) -> float:
    """Parameter t such that the involute is at radius `r` (0 if r ≤ rb)."""
    ratio = (r / rb) ** 2 - 1
    return math.sqrt(ratio) if ratio > 0 else 0.0


def _rotate(p: tuple[float, float], angle: float) -> tuple[float, float]:
    c, s = math.cos(angle), math.sin(angle)
    return (c * p[0] - s * p[1], s * p[0] + c * p[1])


def _inv(a: float) -> float:
    """Involute function inv(α) = tan α − α."""
    return math.tan(a) - a


# ─── Parameters ──────────────────────────────────────────────────────────


@dataclass(frozen=True)
class GearParams:
    """ГОСТ 13755 gear dimensions computed from module + teeth count.

    Attributes mirror the standard symbols:
      m        — модуль
      z        — число зубьев
      alpha    — угол зацепления (rad)
      pitch_d  = m · z              (делительный)
      outer_d  = m · (z + 2)        (вершин, внешняя)
      root_d   = m · (z − 2·c_f)    (впадин, внешняя), c_f = dedendum_factor
      base_d   = pitch_d · cos α    (основной)

    Для внутренней (кольцевой) шестерни роли вершин и впадин
    инвертированы — зуб смотрит к центру:
      int_tip_d  = m · (z − 2)      (вершин, внутрь)
      int_root_d = m · (z + 2·c_f)  (впадин, наружу)
    """

    module: float
    teeth: int
    alpha: float
    pitch_d: float
    outer_d: float
    root_d: float
    base_d: float
    dedendum_factor: float
    int_tip_d: float
    int_root_d: float

    @classmethod
    def of(
        cls,
        module: float,
        teeth: int,
        pressure_angle_deg: float = 20.0,
        dedendum_factor: float = 1.25,
    ) -> "GearParams":
        if teeth < 6:
            raise ValueError("teeth must be >= 6 for a sensible involute profile")
        alpha = math.radians(pressure_angle_deg)
        pitch_d = module * teeth
        return cls(
            module=float(module),
            teeth=int(teeth),
            alpha=alpha,
            pitch_d=pitch_d,
            outer_d=module * (teeth + 2),
            root_d=max(module * (teeth - 2 * dedendum_factor), 0.001),
            base_d=pitch_d * math.cos(alpha),
            dedendum_factor=float(dedendum_factor),
            int_tip_d=max(module * (teeth - 2), 0.001),
            int_root_d=module * (teeth + 2 * dedendum_factor),
        )


# ─── Tooth outline ───────────────────────────────────────────────────────


def _open_tooth(
    params: GearParams,
    samples_per_flank: int,
    samples_per_tip_arc: int,
) -> tuple[float, list[tuple[float, float]]]:
    """Open tooth profile from base_left to base_right (axis +X), base points ON
    the root circle. Returns ``(base_angle, points)``. Shared by the single-tooth
    outline and the full gear periphery.

    The flank uses the mirrored standard involute (CCW → reflected over X, then
    rotated by ``half_tooth + inv(α)``) so the angular position decreases from
    base to tip — the tooth tapers correctly (pitch sits at + half_tooth, ГОСТ).
    """
    rb = params.base_d / 2.0
    ra = params.outer_d / 2.0
    rf = params.root_d / 2.0

    half_tooth = math.pi / (2 * params.teeth)
    inv_alpha = math.tan(params.alpha) - params.alpha
    base_angle = half_tooth + inv_alpha

    t_max = _involute_t_for_radius(rb, ra)
    right_flank: list[tuple[float, float]] = []
    for i in range(samples_per_flank + 1):
        t = t_max * i / samples_per_flank
        x, y = _involute_xy(rb, t)
        right_flank.append(_rotate((x, -y), base_angle))

    left_flank = [(x, -y) for (x, y) in right_flank]

    a_tip_right = math.atan2(right_flank[-1][1], right_flank[-1][0])
    a_tip_left = math.atan2(left_flank[-1][1], left_flank[-1][0])
    # Sweep LEFT tip → RIGHT tip so the arc continues from the left flank (ends at
    # the left tip) to the reversed right flank (starts at the right tip); the
    # other direction crossed the tip → self-intersecting outline → no top face.
    tip_arc: list[tuple[float, float]] = []
    for i in range(1, samples_per_tip_arc):
        frac = i / samples_per_tip_arc
        a = a_tip_left + (a_tip_right - a_tip_left) * frac
        tip_arc.append((ra * math.cos(a), ra * math.sin(a)))

    base_left = (rf * math.cos(-base_angle), rf * math.sin(-base_angle))
    base_right = (rf * math.cos(base_angle), rf * math.sin(base_angle))

    pts = [base_left, *left_flank, *tip_arc, *reversed(right_flank), base_right]
    return base_angle, pts


def one_tooth_outline(
    params: GearParams,
    samples_per_flank: int = 6,
    samples_per_tip_arc: int = 6,
) -> list[tuple[float, float]]:
    """Single tooth CLOSED polyline, axis +X (base on the root circle). The
    returned points include a duplicate first/last vertex for closure."""
    _base_angle, pts = _open_tooth(params, samples_per_flank, samples_per_tip_arc)
    return [*pts, pts[0]]


def gear_outline(
    params: GearParams,
    samples_per_flank: int = 6,
    samples_per_tip_arc: int = 6,
    samples_per_root_arc: int = 4,
) -> list[tuple[float, float]]:
    """The WHOLE gear periphery as ONE closed polyline: each tooth profile joined
    to the next by a root-circle arc in the valley between them.

    Extruded once this is a solid gear built with NO boolean fusing — which
    sidesteps the OCCT hang on coincident arc edges that the old disc-plus-N-teeth
    (fused) recipe hit, especially under a helix twist.
    """
    rf = params.root_d / 2.0
    pitch = 2 * math.pi / params.teeth
    base_angle, tooth = _open_tooth(params, samples_per_flank, samples_per_tip_arc)

    outline: list[tuple[float, float]] = []
    for k in range(params.teeth):
        a = k * pitch
        outline.extend(_rotate(p, a) for p in tooth)
        # Valley arc along the root circle: this tooth's base_right (a + base_angle)
        # → next tooth's base_left (a + pitch − base_angle).
        start = a + base_angle
        end = a + pitch - base_angle
        for j in range(1, samples_per_root_arc + 1):
            ang = start + (end - start) * (j / (samples_per_root_arc + 1))
            outline.append((rf * math.cos(ang), rf * math.sin(ang)))
    outline.append(outline[0])
    return outline


# ─── Sketch helper ───────────────────────────────────────────────────────


def add_gear_sketch(
    sketch: Sketch,
    params: GearParams,
    samples_per_flank: int = 6,
    samples_per_tip_arc: int = 6,
) -> None:
    """Append the gear as ONE closed periphery polyline (teeth + valley arcs).
    Extruding the sketch yields a solid gear in a single operation — no central
    disc and no per-tooth boolean fuse (which OCCT can hang on for coincident
    arc edges, e.g. with a helix twist)."""
    sketch.polyline(
        gear_outline(
            params,
            samples_per_flank=samples_per_flank,
            samples_per_tip_arc=samples_per_tip_arc,
        )
    )


# ─── Internal (ring) gear — зубья внутрь ─────────────────────────────────


def internal_gear_outline(
    params: GearParams,
    samples_per_flank: int = 6,
    samples_per_tip_arc: int = 6,
    samples_per_valley_arc: int = 4,
) -> list[tuple[float, float]]:
    """Внутренняя граница кольцевой шестерни (эпицикла) как ОДИН замкнутый
    контур: зубья смотрят к центру. Вырезав этот контур из наружного диска,
    получаем венец с внутренними зубьями — без булевых fuse (на которых виснет
    OCCT), тем же приёмом, что и ``gear_outline`` для внешней шестерни.

    Геометрия — тот же эвольвентный аппарат, но инвертированный: вершина зуба
    (addendum) уходит ВНУТРЬ к ``int_tip_d/2``, впадина — НАРУЖУ к
    ``int_root_d/2``. Полуугловая ширина зуба растёт с радиусом
    (внутренний зуб = впадина внешней шестерни):

        φ(r) = π/(2z) + inv(α_r) − inv(α),   cos α_r = rb/r.

    Ниже основной окружности (``r < rb``, бывает при z ≲ 33, когда вершина
    оказывается внутри базы) эвольвенты нет — фланг продолжается радиальным
    отрезком под углом ``φ(rb)``.
    """
    z = params.teeth
    rb = params.base_d / 2.0
    ra = params.int_tip_d / 2.0   # вершины, внутрь (малый радиус)
    rf = params.int_root_d / 2.0  # впадины, наружу (большой радиус)

    half_tooth = math.pi / (2 * z)
    inv_a = _inv(params.alpha)
    pitch = 2 * math.pi / z

    def phi(r: float) -> float:
        """Полуугловая ширина зуба на радиусе r (радиальный отрезок ниже базы)."""
        ar = math.acos(rb / r) if r > rb else 0.0
        return half_tooth + _inv(ar) - inv_a

    r_flank_lo = max(ra, rb)      # нижний предел эвольвенты
    phi_tip = phi(r_flank_lo)     # угол на вершине (или на базе при ra < rb)
    below_base = ra < rb - 1e-9   # нужен ли радиальный отрезок база→вершина

    outline: list[tuple[float, float]] = []
    for k in range(z):
        a = k * pitch
        # 1. Нижний фланг: от впадины rf внутрь к r_flank_lo (эвольвента,
        #    угол a − φ(r), радиус убывает → угол растёт).
        for i in range(samples_per_flank + 1):
            r = rf + (r_flank_lo - rf) * (i / samples_per_flank)
            ang = a - phi(r)
            outline.append((r * math.cos(ang), r * math.sin(ang)))
        # 2. Радиальный отрезок вниз к вершине ra (только если ra < rb).
        if below_base:
            ang = a - phi_tip
            outline.append((ra * math.cos(ang), ra * math.sin(ang)))
        # 3. Дуга вершины при ra от −φ_tip к +φ_tip (внутренняя «шапка»).
        for i in range(1, samples_per_tip_arc):
            ang = a - phi_tip + 2 * phi_tip * (i / samples_per_tip_arc)
            outline.append((ra * math.cos(ang), ra * math.sin(ang)))
        # 4. Верхний фланг: радиальный отрезок вверх (при ra < rb), затем
        #    эвольвента наружу к впадине rf (угол a + φ(r)).
        if below_base:
            ang = a + phi_tip
            outline.append((ra * math.cos(ang), ra * math.sin(ang)))
        for i in range(samples_per_flank + 1):
            r = r_flank_lo + (rf - r_flank_lo) * (i / samples_per_flank)
            ang = a + phi(r)
            outline.append((r * math.cos(ang), r * math.sin(ang)))
        # 5. Дуга впадины при rf до следующего зуба.
        start = a + phi(rf)
        end = a + pitch - phi(rf)
        for j in range(1, samples_per_valley_arc + 1):
            ang = start + (end - start) * (j / (samples_per_valley_arc + 1))
            outline.append((rf * math.cos(ang), rf * math.sin(ang)))

    outline.append(outline[0])
    return outline


def add_internal_gear_sketch(
    sketch: Sketch,
    params: GearParams,
    samples_per_flank: int = 6,
    samples_per_tip_arc: int = 6,
    samples_per_valley_arc: int = 4,
) -> None:
    """Добавляет зубчатое отверстие кольцевой шестерни (зубья внутрь) в скетч
    одной замкнутой полилинией. Вырезав его из наружного диска, получаем венец —
    ср. ``add_gear_sketch`` для внешней шестерни."""
    sketch.polyline(
        internal_gear_outline(
            params,
            samples_per_flank=samples_per_flank,
            samples_per_tip_arc=samples_per_tip_arc,
            samples_per_valley_arc=samples_per_valley_arc,
        )
    )
