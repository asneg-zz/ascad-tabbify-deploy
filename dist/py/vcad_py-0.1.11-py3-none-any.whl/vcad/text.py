"""Text → glyph-outline contours for the editable ``text`` sketch element.

Mirrors the frontend's ``src/sketch/textContours.ts``: a precomputed glyph
table (``_glyphs.json``, em-normalised DejaVu Sans outlines, +Y up) is laid out
by advance width and scaled to ``font_size``. Each contour is a closed loop —
a letter's outer outline or an inner counter (the bowl of О/Р/В…). Counters
nest as holes via the same containment grouping circles already use.

Contours are returned RELATIVE to the text anchor (baseline-left at the
origin). The ``text`` element stores them in ``text_contours`` so the viewer
and extruder never need a font — exactly like the in-app dialog bakes them.
"""

from __future__ import annotations

import json
from importlib import resources
from typing import TypedDict


class _Glyph(TypedDict):
    advance: float
    contours: list[list[list[float]]]  # loops → points → [x, y], em-normalised

# Minimum gap (sketch units) between consecutive points. Flattened Béziers can
# fold several samples onto one spot; emitted verbatim they become zero-length
# OCCT edges and the extrude throws (curved letters fail). Drop closer points.
_DEDUP_TOL = 1e-3

_GLYPHS: dict[str, _Glyph] | None = None


def _glyphs() -> dict[str, _Glyph]:
    global _GLYPHS
    cache = _GLYPHS
    if cache is None:
        raw = resources.files("vcad").joinpath("_glyphs.json").read_text(encoding="utf-8")
        cache = json.loads(raw)["glyphs"]
        _GLYPHS = cache
    return cache


def available_chars() -> set[str]:
    """Characters the bundled glyph table can render."""
    return set(_glyphs().keys())


def text_to_contours(text: str, font_size: float) -> list[list[tuple[float, float]]]:
    """Closed glyph contours for ``text`` at ``font_size`` (em height in sketch
    units). Loops are relative to the baseline-left anchor, +Y up, each closed
    (first vertex repeated). Unknown characters advance by a space."""
    if not text or font_size <= 0:
        return []

    glyphs = _glyphs()
    space_adv = glyphs[" "]["advance"] if " " in glyphs else 0.5
    pen_x = 0.0
    out: list[list[tuple[float, float]]] = []

    for ch in text:
        g = glyphs.get(ch)
        if g is None:
            pen_x += space_adv * font_size
            continue
        for raw in g["contours"]:
            loop: list[tuple[float, float]] = []
            for x, y in raw:
                px = pen_x + x * font_size
                py = y * font_size
                if loop and abs(loop[-1][0] - px) < _DEDUP_TOL and abs(loop[-1][1] - py) < _DEDUP_TOL:
                    continue
                loop.append((px, py))
            # Drop trailing points that fold back onto the first, then close exactly.
            while (
                len(loop) >= 2
                and abs(loop[0][0] - loop[-1][0]) < _DEDUP_TOL
                and abs(loop[0][1] - loop[-1][1]) < _DEDUP_TOL
            ):
                loop.pop()
            if len(loop) >= 3:
                loop.append(loop[0])
                out.append(loop)
        pen_x += g["advance"] * font_size

    return out
